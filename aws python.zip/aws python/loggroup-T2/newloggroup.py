import boto3
from datetime import datetime
import json

class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()

        return json.JSONEncoder.default(self, o)

def convert_bytes_to_mb(bytes_value):
    return bytes_value / (1024 * 1024)

regions = ["ap-south-1"]

log_group_list = []

for region in regions:
    try:
        client = boto3.client('logs', region_name=region)
        next_token = None

        while True:
            if next_token:
                log_groups = client.describe_log_groups(nextToken=next_token)
            else:
                log_groups = client.describe_log_groups()

            for log_group in log_groups["logGroups"]:
                log_group_data = {
                    "logGroupName": log_group["logGroupName"],
                    "region": region,
                    "creationTime": datetime.fromtimestamp(log_group["creationTime"] / 1000),
                    "stored_MB": convert_bytes_to_mb(log_group["storedBytes"]),
                    "retentionInDays": log_group.get("retentionInDays"),
                    "lastEventTimestamp": None,
                    "logStreamName": None
                }

                try:
                    lastEventTimestamp = {}
                    log_token = None

                    while True:
                        if log_token:
                            log_streams = client.describe_log_streams(logGroupName=log_group["logGroupName"], nextToken=log_token)
                        else:
                            log_streams = client.describe_log_streams(logGroupName=log_group["logGroupName"])

                        for log_stream in log_streams["logStreams"]:
                            if "lastEventTimestamp" in log_stream:
                                lastEventTimestamp[log_stream["lastEventTimestamp"]] = log_stream["logStreamName"]

                        log_token = log_streams.get('nextToken')
                        if log_token is None:
                            break

                    lastEventTimestamp_keys = list(lastEventTimestamp.keys())
                    last_timestamp = sorted(lastEventTimestamp_keys)[-1] if len(lastEventTimestamp) > 0 else None
                    log_group_data["lastEventTimestamp"] = datetime.fromtimestamp(last_timestamp / 1000).strftime('%d %Y, %b') if last_timestamp is not None else None
                    log_group_data["logStreamName"] = lastEventTimestamp.get(last_timestamp)

                except Exception as e:
                    print(f"Error occurred while processing log streams for log group {log_group['logGroupName']}: {e}")

                log_group_list.append(log_group_data)

            next_token = log_groups.get('nextToken')
            if next_token is None:
                break

    except Exception as e:
        print(f"Error occurred while processing AWS logs in region {region}: {e}")

print(json.dumps(log_group_list, indent=1, cls=DateTimeEncoder))
