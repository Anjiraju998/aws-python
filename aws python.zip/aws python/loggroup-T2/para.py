import boto3
from botocore.exceptions import NoCredentialsError

def list_ssm_parameters():
    try:
        
        # client = boto3.client('logs', region_name="ap-south-1")
        # Create a boto3 client for SSM
        ssm_client = boto3.client('ssm', region_name="ap-south-1")

        # Retrieve the list of parameters
        parameters = ssm_client.describe_parameters()

        for param in parameters.get('Parameters', []):
            param_name = param['Name']

            # Retrieve the parameter history
            history = ssm_client.get_parameter_history(Name=param_name)

            # Find the last modified date
            last_modified_date = None
            if history.get('Parameters'):
                last_modified_date = history['Parameters'][0]['LastModifiedDate']

            print(f"Parameter: {param_name}, Last Used: {last_modified_date}")

    except NoCredentialsError:
        print("Credentials not available")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    list_ssm_parameters()