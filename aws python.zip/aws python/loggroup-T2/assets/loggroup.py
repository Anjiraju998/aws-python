import boto3
from datetime import datetime
import logging
import json

class AwsCloudWatchLogs:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_loggroup_inventory(self):
        next_token = None
        log_group_data = {}
        log_group_list =[]
        for region in self.regions:
            try:
                client = boto3.client('logs', region_name=region) 
                while True:
                    if next_token:
                        log_groups = client.describe_log_groups(nextToken = next_token)
                    else:
                        log_groups = client.describe_log_groups()
                    for log_group in log_groups["logGroups"]:
                        log_group_data = {
                            "account": self.account_id,
                            "region": region,
                            "loggroupname":log_group["logGroupName"],
                            "creationtime": datetime.fromtimestamp(log_group["creationTime"]/1000).strftime('%Y-%m-%d'),
                            "stored(mb)": log_group["storedBytes"] / (1024 * 1024),
                            "retentionindays": log_group["retentionInDays"] if  "retentionInDays" in log_group else "Never",                                            
                        }
                        log_token= None
                        lastEventTimestamp = {}
                        while True:
                            if log_token:
                                log_streams = client.describe_log_streams(
                                    logGroupName=log_group["logGroupName"],
                                    nextToken = log_token)
                            else:
                                log_streams = client.describe_log_streams(
                                    logGroupName=log_group["logGroupName"]
                                )

                            for log_stream in log_streams["logStreams"]:        
                                if "lastEventTimestamp" in log_stream:
                                    lastEventTimestamp[log_stream["lastEventTimestamp"]]=log_stream["logStreamName"]

                            log_token = log_streams.get('nextToken')
                            if not log_token:
                                break
                        lastEventTimestamp_keys = list(lastEventTimestamp.keys())                        
                        last_timestamp = sorted(lastEventTimestamp_keys)[-1] if len(lastEventTimestamp) > 0 else None
                        log_group_data["lastEventTimestamp"] = datetime.fromtimestamp(last_timestamp/1000).strftime('%Y-%m-%d') if last_timestamp != None else None
                    log_group_list.append(log_group_data)
                    next_token =  log_groups.get('nextToken')  
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_acm_inventory for region {region}: {str(e)}"
                )
                continue
        return log_group_list
    
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awscloudwatchlogs=AwsCloudWatchLogs(account_id=accountid,regions=aws_regions)
cloudwatchlogs_assets = [
    {
        "service" : "cloudwatch",
        "friendlyname": "cloudwatch",
        "subservice" : {
            "loggroup" : awscloudwatchlogs.get_loggroup_inventory()
        }
    }
]

print(json.dumps(cloudwatchlogs_assets, indent=2))