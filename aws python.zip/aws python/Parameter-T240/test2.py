import boto3
from datetime import datetime

# Initialize the Boto3 client for SSM (Simple Systems Manager)
ssm_client = boto3.client('ssm', region_name = "ap-south-1")
parameter_name = 'test1'

# Retrieve parameter metadata including the creation time
response = ssm_client.get_parameter(
    Name=parameter_name
)

# Extract the creation time from the response
creation_time = response['Parameter']['LastModifiedDate']

# Convert the creation time to a more readable format
creation_time = datetime.strftime(creation_time, "%Y-%m-%d %H:%M:%S")

print(f"Creation time of parameter '{parameter_name}': {creation_time}")