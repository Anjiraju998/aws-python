import boto3
import json
from datetime import datetime
import logging

regions = ["ap-south-1"]
for region in regions:
    client = boto3.client('ssm', region_name = region)
parameter_name = 'test1'
response = client.get_parameter_history(
    Name=parameter_name
)
for data in response['Parameters']:
    creation_dates = data['LastModifiedDate']
    creation_date = response['Parameters'][0]['LastModifiedDate']
    print(creation_date)   