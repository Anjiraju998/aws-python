import boto3
import json
from datetime import datetime
import logging

class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()
        return json.JSONEncoder.default(self, o)
class AWSParameterAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_parameter_inventory(self):
        pr_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ssm', region_name = region)
                while True:
                    if next_token:
                        parameters = client.describe_parameters(
                            nextToken = next_token
                        )
                    else:
                        parameters = client.describe_parameters()
                    for parameter in parameters["Parameters"]:
                        para_name = parameter["Name"]
                        parameters_get = client.get_parameter_history(
                            Name= para_name
                        )
                        for parameter_g in parameters_get["Parameter"]:
                        # print(parameters_get)   
                            pr_list.append({
                                # "account": self.account_id,
                                # "region": region,
                                # "name" : parameter["Name"],
                                # "type" : parameter["Type"],
                                "lastmodified" : parameter_g["LastModifiedDate"],
                                # "creation_date" : parameters_get['Parameter'][-1]['LastModifiedDate']
                                "creation_date" : datetime.strptime(parameters_get["Parameter"][0]["LastModifiedDate"], '%Y-%m-%d')
                            })
                            # print(parameters_get['Parameters'])
                    next_token = parameters.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_parameter_inventory for region {region}: {str(e)}"
                )
                continue
            return pr_list
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awsparameterassets=AWSParameterAssets(account_id=accountid,regions=aws_regions)

parameter_assets = [
    {
        "service" : "acm",
        "subservice" : {
            "projects" : awsparameterassets.get_parameter_inventory()
        }
    }
]

print(json.dumps(parameter_assets, indent=2, cls=DateTimeEncoder))
