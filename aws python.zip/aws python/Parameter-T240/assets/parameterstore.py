import boto3
import json
from datetime import datetime
import logging

class AWSParameterAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_parameter_inventory(self):
        pr_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ssm', region_name = region)
                while True:
                    if next_token:
                        parameters = client.describe_parameters(
                            NextToken = next_token
                        )
                    else:
                        parameters = client.describe_parameters()
                    for parameter in parameters["Parameters"]:
                        pr_list.append({
                            "account": self.account_id,
                            "region": region,
                            "name" : parameter["Name"],
                            "type" : parameter["Type"],
                            "lastmodified" : datetime.strftime(parameter["LastModifiedDate"], '%Y-%m-%d') 
                        })
                    next_token = parameters.get('NextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_parameter_inventory for region {region}: {str(e)}"
                )
                continue
        return pr_list
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awsparameterassets=AWSParameterAssets(account_id=accountid,regions=aws_regions)

parameter_assets = [
    {
        "service" : "SSM",
        "friendlyname": "Systems Manager",
        "subservice" : {
            "parameterstore" : awsparameterassets.get_parameter_inventory()
        }
    }
]

print(json.dumps(parameter_assets, indent=2))
