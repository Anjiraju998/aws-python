import boto3
import json
from datetime import datetime,timezone
import logging

class AWS_ECS_ASSETS:

    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id
    
    def get_ecs_cluster_assets(self):
        ecs_cluster_output =[]
        next_token= None
        for region in self.regions:
            try:
                ecs_client = boto3.client('ecs', region_name= region)   
                while True:
                    if next_token : ecs_cluster_response = ecs_client.list_clusters(nextToken = next_token)
                    else: ecs_cluster_response = ecs_client.list_clusters()    

                    for cluster in ecs_cluster_response['clusterArns']: 
                        cluster_describe = ecs_client.describe_clusters(clusters = [cluster])
                        
                        for i in cluster_describe['clusters']:
                            ecs_cluster_output.append({
                                'account_id': self.account_id,
                                "region"    : region,
                                'name'      : i['clusterName'],
                                'status'    : i['status'],
                                })
                    next_token = ecs_cluster_response.get('NextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(f"Error in ECS clusters for region {region}: {str(e)}" )
        return ecs_cluster_output
    
    def get_ecs_service_assets(self , clusters):
        ecs_service_output =[]
        services_next_token = None
        for c in clusters:
            try:
                ecs_client = boto3.client('ecs', region_name= c['region'])
                while True:
                    if services_next_token:
                        service_response = ecs_client.list_services(
                            cluster = c['name'],
                            nextToken = services_next_token
                        )
                    else :
                        service_response = ecs_client.list_services(
                            cluster = c['name'],
                        )

                    for s in service_response['serviceArns']:
                        describe_service = ecs_client.describe_services(
                            cluster = c['name'],
                            services = [s]
                        )
                        for serv in describe_service['services']:   
                            ecs_scaling_next_token = None
                            try:
                                scaling_client = boto3.client('application-autoscaling', region_name= c['region'])
                                while True:
                                    if ecs_scaling_next_token: 
                                        scaling_target_response = scaling_client.describe_scalable_targets(
                                            ServiceNamespace  = 'ecs',
                                            ResourceIds       = [f"service/{c['name']}/{serv['serviceName']}"],
                                            ScalableDimension = 'ecs:service:DesiredCount',
                                            NextToken         = ecs_scaling_next_token
                                        )
                                    else:
                                        scaling_target_response =  scaling_client.describe_scalable_targets(
                                            ServiceNamespace    =  'ecs',
                                            ResourceIds       = [f"service/{c['name']}/{serv['serviceName']}"],
                                            ScalableDimension   =  'ecs:service:DesiredCount'
                                        )
                                    for scaling in scaling_target_response['ScalableTargets']:
                                        ecs_service_output.append({
                                            'account_id'        : self.account_id,
                                            'region'            : c['region'],
                                            'cluster'           : c['name'],
                                            'service_name'      : serv['serviceName'],
                                            'status'            : serv['status'],
                                            'launch_type'       : serv['launchType'],
                                            'task_definition'   : serv['taskDefinition'],
                                            'desired_count'     : serv['desiredCount']  ,
                                            'running_count'     : serv['runningCount'],
                                            'min_capacity'      : scaling['MinCapacity'],
                                            'max_capacity'      : scaling['MaxCapacity'],
                                            'creation_time'     : datetime.strftime(scaling['CreationTime'], '%Y-%m-%d'),                                                
                                        })
                                                                            
                                    ecs_scaling_next_token = scaling_target_response.get('NextToken')
                                    if not ecs_scaling_next_token:
                                        break
                            except Exception as e:
                                logging.error(f"Error in getting autoscale for service {serv['serviceName']} for region {c['region']}: {str(e)}" )
                    
                    services_next_token = service_response.get('NextToken')
                    if not services_next_token : break                
            except Exception as e:
                logging.error(f"Error in ECS services for cluster {c['name']} for region {c['region']}: {str(e)}" )
                
        return ecs_service_output

    def get_task_definitions(self):
        td_output = []
        td_next_token = None
        for region in self.regions:
            try:
                td_client = boto3.client('ecs', region_name=region )
                while True:
                    if td_next_token:
                        td_family_response =  td_client.list_task_definition_families( nextToken = td_next_token )
                    else:
                        td_family_response =  td_client.list_task_definition_families()                    

                    for td_family in td_family_response['families']:

                        try:
                            td = td_client.describe_task_definition(taskDefinition = td_family)
                            task_definition = td['taskDefinition']                        

                            td_output.append({
                                'account_id'            : self.account_id,
                                'region'                : region,
                                'task_definition_name'  : task_definition['family'],
                                'status'                : task_definition['status'],
                                'network'               : task_definition['networkMode'],
                                'latest_revision'       : task_definition['revision'],
                                'compatibilities'       : task_definition['compatibilities'],
                                'cpu'                   : task_definition['cpu'],
                                'memory'                : task_definition['memory'],
                                'registered_at'         : datetime.strftime(task_definition['registeredAt'], '%Y-%m-%d'),
                            })
                        except Exception as f:
                            td_output.append({
                                'account_id'            : self.account_id,
                                'region'                : region,
                                'task_definition_name'  : td_family,
                                'status'                : "INACTIVE",
                                'network'               : "-",
                                'latest_revision'       : "-",
                                'compatibilities'       : "-",
                                'cpu'                   : "-",
                                'memory'                : "-",
                                'registered_at'         : "-",
                            })
                            logging.error(f"str{f}")
                    td_next_token = td_family_response.get('nextToken')
                    if not td_next_token: break
            except Exception as e:
                logging.error(f"Error in get_task_definitions for region {region}: {str(e)}" )
        
        return td_output



ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

AwsECSAssets=AWS_ECS_ASSETS(account_id=accountid,regions=aws_regions)
clusters = AwsECSAssets.get_ecs_cluster_assets()

ecs_assets=    [{
        "service"       : 'ECS',
        "friendly_name" : 'Elastic Container Service',
        "subservices": {
            "clusters": clusters,
            "services" : AwsECSAssets.get_ecs_service_assets(clusters),
            "taskDefinitions" : AwsECSAssets.get_task_definitions(),
        }        
    }]

print(json.dumps(ecs_assets, indent=2))