import boto3
import json
import logging

class AwsDynamoDBAssets:    
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_dynamodb_inventory(self):
        next_token = None
        tables = []
        for region in self.regions:
            try:
                client = boto3.client('dynamodb')
                while True:
                    if next_token:
                        response = client.list_tables(
                            nexttoken=next_token
                        )
                    else:
                        response = client.list_tables()
                    for table_names in response['TableNames']:
                        response = client.describe_table(TableName=table_names)
                        tables.append({
                            "account"                   : self.account_id,
                            "region"                    : region,
                            'name'                      : response['Table']['TableName'],
                            'tablestatus'               : response['Table']['TableStatus'],
                            'itemcount'                 : response['Table']['ItemCount'],
                            'tablesizebytes'            : response['Table']['TableSizeBytes'],
                            'readcapacityunits'         : response['Table']['ProvisionedThroughput']['ReadCapacityUnits'],
                            'writecapacityunits'        : response['Table']['ProvisionedThroughput']['WriteCapacityUnits']
                        })
                    next_token = response.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_dynamodb_inventory for region {region}: {str(e)}"
                )
                continue 
            return tables
        
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')      
    
AwsDynamoDBAssets =  AwsDynamoDBAssets(account_id=accountid, regions=aws_regions)

AwsDynamoDB_Assets = [
    {
        "service"      : "DynamoDB",
        "friendlyname" : "DynamoDB",
        "subservice"   : {
            "tables"   : AwsDynamoDBAssets.get_dynamodb_inventory()
        }
    }
] 
print(json.dumps(AwsDynamoDB_Assets, indent=2))