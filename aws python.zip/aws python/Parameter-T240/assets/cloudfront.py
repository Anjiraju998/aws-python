import boto3
import logging
import json

class AWSCloudFrontAssets:
    def __init__(self, account_id):
        self.account_id=account_id

    def get_cloudfront_inventory(self):
        cf_list = []
        next_token = None
        try:
            client = boto3.client('cloudfront')
            while True:
                if next_token:
                    response = client.list_distributions(NextToken=next_token)
                else:
                    response = client.list_distributions()
                    # print(response)
                for cf in response['DistributionList']['Items']:
                        cname = []
                        if 'AliasICPRecordals' in cf:
                            for name in cf['AliasICPRecordals']:
                                cname.append(name['CNAME'])
                        if 'Tags' in cf:
                            cf_tags=[f"{tag['Key']}: {tag['Value']}" for tag in cf['Tags']]
                        else:
                            cf_tags=[]
                        cf_list.append(
                            {
                                "distribution id": cf['Id'],
                                "price class": cf['PriceClass'],
                                "status": "Enabled" if cf['Enabled'] else "Disabled",
                                "domain ": cf['DomainName'],
                                "cnames": cname,
                                "tags": cf_tags
                            }
                        )
                next_token = response.get('NextToken')
                if not next_token:
                    break
                    
        except Exception as e:
            logging.error(
                f"Error in get_cloudfront_inventory: {str(e)}"
            )
        return cf_list
accountid=boto3.client('sts').get_caller_identity().get('Account')
awsparameterassets=AWSCloudFrontAssets(account_id=accountid)

parameter_assets = [
    {
        "service" : "SSM",
        "friendlyname": "Systems Manager",
        "subservice" : {
            "parameterstore" : awsparameterassets.get_cloudfront_inventory()
        }
    }
]

print(json.dumps(parameter_assets, indent=2))