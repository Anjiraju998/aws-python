import boto3
from datetime import datetime, timezone 
import logging
import json

class AWSRedshiftAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_redshift_inventory(self):
        marker = None
        redishift_data = []
        for region in self.regions:
            try:
                client = boto3.client('redshift', region_name = region)
                while True:
                    if marker:
                        redishift_des = client.describe_clusters(
                            Marker = marker
                        )
                    else:
                        redishift_des = client.describe_clusters()
                    for redishift in redishift_des["Clusters"]:
                        cluster_tags = [f"{tag['Key']}: {tag['Value']}" for tag in redishift["Tags"]] if "Tags" in redishift else []
                        redishift_data.append({
                            "account": self.account_id,
                            "region": region,
                            "clusteridentifier" : redishift["ClusterIdentifier"],
                            "nodetype" : redishift["NodeType"],
                            "creationtime" : datetime.strftime(redishift["ClusterCreateTime"], '%Y-%m-%d'),
                            "availabilityzone" : redishift["AvailabilityZone"],
                            "version" : redishift["ClusterVersion"],
                            "numberofnodes" : redishift["NumberOfNodes"],
                            "tags" : cluster_tags
                        })
                    marker = redishift_des.get('Marker')
                    if not marker:
                        break      
            except Exception as e:
                logging.error(
                    f"Error in get_redshift_inventory for region {region}: {str(e)}"
                )
                continue
        return redishift_data
    def get_snapshot_inventory(self):
        snapshot_data = []
        marker = None
        for region in self.regions:
            try:
                client = boto3.client('redshift', region_name = region)
                while True:
                    if marker:
                        snapshots = client.describe_cluster_snapshots(
                            Marker = marker
                        )
                    else:
                        snapshots = client.describe_cluster_snapshots()
                    for snapshot in snapshots["Snapshots"]:
                        snapshot_tag = [f"{tag['Key']}: {tag['Value']}" for tag in snapshot["Tags"]] if "Tags" in snapshot else []
                        snapshot_data.append({
                            "account": self.account_id,
                            "region": region,
                            "snapshotidentifier" : snapshot["SnapshotIdentifier"],
                            "type" : snapshot["SnapshotType"],
                            "creationtime" : datetime.strftime(snapshot["SnapshotCreateTime"], '%Y-%m-%d'),
                            "availabilityZone" : snapshot["AvailabilityZone"],
                            "status" : snapshot["Status"],
                            "Tags" : snapshot_tag
                        })
                    marker = snapshots.get('Marker')
                    if not marker:
                        break  
            except Exception as e:
                logging.error(
                    f"Error in get_snapshot_inventory for region {region}: {str(e)}"
                )
                continue
        return snapshot_data
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awsredshiftassets=AWSRedshiftAssets(account_id=accountid,regions=aws_regions) 
redshift_assets = [
    {
        "service" : "redshift",
        "friendlyname": "Redshift",
        "subservices" : {
            "cluster" : awsredshiftassets.get_redshift_inventory(),
            "snapshot" : awsredshiftassets.get_snapshot_inventory()
        }
    }
]
print(json.dumps(redshift_assets, indent=2))
                
    
    
    
    
    
    
    
    
    
    