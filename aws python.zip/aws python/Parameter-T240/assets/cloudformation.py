import boto3
import json
from datetime import datetime,timezone
import logging

class CloudFormation_Assets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id

    def get_cf_stacks(self):

        cf_stacks_output =[]

        stack_list_next_token= None
        for region in self.regions:
            cf_client = boto3.client('cloudformation', region_name= region)
            try:
                while True:
                    if stack_list_next_token:
                        stack_list = cf_client.list_stacks(NextToken=stack_list_next_token)
                    else:
                        stack_list = cf_client.list_stacks()
                    
                    for stack in stack_list['StackSummaries']:
                        cf_stacks_output.append({
                            'account'       : self.account_id,
                            'region'        : region,
                            'stack_name'    : stack['StackName'],
                            'creation_time' : datetime.strftime(stack['CreationTime'],'%d-%m-%Y'),
                            'last_updated'  : datetime.strftime(stack['LastUpdatedTime'],'%d-%m-%Y') if 'LastUpdatedTime' in stack else None,
                            'stack_status'  : stack['StackStatus'],
                            'deleted_time'  : datetime.strftime(stack['DeletionTime'], '%d-%m-%Y') if 'DeletionTime' in stack else None,
                            'stack_drift_status'    : stack['DriftInformation']['StackDriftStatus'],
                            'stack_drift_last_check':  datetime.strftime(stack['DriftInformation']['LastCheckTimestamp'], '%d-%m-%Y') if 'LastCheckTimestamp' in stack['DriftInformation'] else None,
                        },)
                    
                    stack_list_next_token = stack_list.get('NextToken')
                    if not stack_list_next_token: 
                        break
                        
            except Exception as e:
                logging.error(f"Error in get_cf_stacks for {region} : {str(e)}")
                continue

        return cf_stacks_output


ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

cf_assets = CloudFormation_Assets(account_id=accountid,regions=aws_regions)

stack_lists = [{
    "resource"      :  "CloudFormation",
    "friendly_name" :   "CloudFormation",
    "subservices"   :   {
        "stacks"    : cf_assets.get_cf_stacks()
    }
}]

print(json.dumps(stack_lists,indent=2))