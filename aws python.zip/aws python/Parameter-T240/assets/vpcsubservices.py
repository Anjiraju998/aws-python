import boto3
import json
from datetime import datetime
import logging

class AWSVpcAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_internetgateway_inventory(self):
        igway_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region) 
                while True:
                    if next_token:
                        igways = client.describe_internet_gateways(
                            nextToken = next_token
                        )
                    else:
                        igways = client.describe_internet_gateways()
                    for igw in igways["InternetGateways"]:
                        if "Tags" in igw:
                            igw_tag = [f"{tag['Key']}: {tag['Value']}" for tag in igw["Tags"]]
                        for Attachment in igw["Attachments"]:
                            igway_list.append({
                                "account": self.account_id,
                                "region": region,
                                "id" :  igw["InternetGatewayId"],
                                "vpcid" : Attachment["VpcId"],
                                "state" : Attachment["State"],
                                "tag" : igw_tag
                            })
                    next_token = igways.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_internetgateway_inventory for region {region}: {str(e)}"
                )
                continue
        return igway_list
    def get_endpoint_inventory(self):
        endpoint_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region)
                while True:
                    if next_token:
                        endpoints = client.describe_vpc_endpoints(
                            nextToken = next_token
                        )
                    else:
                        endpoints = client.describe_vpc_endpoints()
                    for endpoint in endpoints["VpcEndpoints"]:
                        if "Tags" in endpoint:
                            endpoint_tag = [f"{tag['Key']}: {tag['Value']}" for tag in endpoint["Tags"]]                
                        endpoint_list.append({
                            "account": self.account_id,
                            "region": region,
                            "vpcendpoint" : endpoint["VpcEndpointId"],
                            "vpcendpointtype" : endpoint["VpcEndpointType"],
                            "endpointvpcid" : endpoint["VpcId"],
                            "endpointservice" : endpoint["ServiceName"],
                            "status" : endpoint["State"],
                            "creation" : datetime.strftime(endpoint["CreationTimestamp"], '%Y-%m-%d'),
                            "tag" : endpoint_tag 
                        })
                    next_token = endpoints.get('nextToken')
                    if not next_token:
                        break    
            except Exception as e:
                logging.error(
                    f"Error in get_endpoint_inventory for region {region}: {str(e)}"
                )
                continue
        return endpoint_list
    def get_networkacl_inventory(self):
        nacl_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region)
                while True:
                    if next_token:
                        net_acls = client.describe_network_acls(
                            nextToken = next_token
                        )
                    else:
                        net_acls = client.describe_network_acls()
                    for net_acl in net_acls["NetworkAcls"]:
                        if "Tags" in net_acl:
                            net_acl_tag = [f"{tag['Key']}: {tag['Value']}" for tag in net_acl["Tags"]] 
                        nacl_list.append({
                            "account": self.account_id,
                            "region": region,
                            "id" : net_acl["NetworkAclId"],
                            "vpcid" : net_acl["VpcId"],
                            "tag" : net_acl_tag              
                            })
                    next_token = net_acls.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_networkacl_inventory for region {region}: {str(e)}"
                )
                continue
        return nacl_list
    def get_vpc_peering_inventory(self):
        vpcpeering_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region) 
                while True:
                    if next_token:
                        vpcpeerings = client.describe_vpc_peering_connections(
                            
                        )
                    else:
                        vpcpeerings = client.describe_vpc_peering_connections(                        )
                    for peerings in vpcpeerings['VpcPeeringConnections']:
                        if "Tags" in peerings:
                            peerings_tag = [f"{tag['Key']}: {tag['Value']}" for tag in peerings["Tags"]]
                        vpcpeering_list.append({
                            "account": self.account_id,
                            "region": region,
                            "vpcpeeringconnectionid" : peerings['VpcPeeringConnectionId'],
                            "acceptercidrblock" : peerings['AccepterVpcInfo']['CidrBlock'],
                            "accepterownerid" : peerings['AccepterVpcInfo']['OwnerId'],
                            "acceptervpcid" : peerings['AccepterVpcInfo']['VpcId'],
                            "accepterregion" : peerings['AccepterVpcInfo']['Region'],
                            "requestercidrblock" : peerings["RequesterVpcInfo"]["CidrBlock"],
                            "requesterownerid" : peerings["RequesterVpcInfo"]["OwnerId"],
                            "requestervpcid" : peerings["RequesterVpcInfo"]["VpcId"],
                            "requesterregion" : peerings["RequesterVpcInfo"]["Region"],
                            "status" : peerings["Status"]["Code"],
                            "tags" : peerings_tag if "Tags" in peerings else None
                            }) 
                    next_token = vpcpeerings.get('nextToken')
                    if not next_token:
                        break       
            except Exception as e:
                logging.error(
                    f"Error in get_vpc_peering_inventory for region {region}: {str(e)}"
                )
                continue
        return vpcpeering_list

ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awsvpcassets=AWSVpcAssets(account_id=accountid,regions=aws_regions)  

vpc_assets = [
    {
        "service" : "vpc",
        "friendlyname": "Virtual Private Cloud",
        "subservice" : {
            "Internetgateway" : awsvpcassets.get_internetgateway_inventory(),
            "endpoint" : awsvpcassets.get_endpoint_inventory(),
            "networkacl" : awsvpcassets.get_networkacl_inventory(),
            "peering" : awsvpcassets.get_vpc_peering_inventory()
        }
    }
]

print(json.dumps(vpc_assets, indent=2))
