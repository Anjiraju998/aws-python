import boto3
import json
import logging
from datetime import datetime

class AwsEFSAssets:    
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_efs_inventory(self):
        next_token = None
        file_system = []
        for region in self.regions:
            try:
                client = boto3.client('efs',)
                while True:
                    if next_token:
                        response = client.describe_file_systems(
                            nexttoken=next_token
                        )
                    else:
                        response = client.describe_file_systems()
                    for filesystem in response['FileSystems']:
                        file_system.append({
                            "account"         : self.account_id,
                            "region"          : region,
                            'name'            : filesystem['Name'],
                            'filesystemid'    : filesystem['FileSystemId'],
                            'creationtime'    : datetime.strftime(filesystem['CreationTime'], '%Y-%m-%d'),
                            'performancemode' : filesystem['PerformanceMode'],
                            'lifecyclestate'  : filesystem['LifeCycleState'],
                            'size'            : filesystem['SizeInBytes']['Value'],
                            'tags'            : [f"{tag['Key']}: {tag['Value']}" for tag in filesystem["Tags"]]
                            
                        })
                    next_token = response.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_efs_inventory for region {region}: {str(e)}"
                )
                continue 
            return file_system

ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')      
    
AwsEFSAssets =  AwsEFSAssets(account_id=accountid, regions=aws_regions)

AwsEFS_Assets = [
    {
        "service"      : "EFS",
        "friendlyname" : "Elastic File Storage",
        "subservice"   : {
            "file systems"   : AwsEFSAssets.get_efs_inventory()
        }
    }
] 

print(json.dumps(AwsEFS_Assets, indent=2))
