import boto3
import botocore
import logging
import json

class AWSS3Assets:
    def __init__(self, account_id):
        self.account_id=account_id

    def get_s3_buckets_inventory(self):
        s3_list = []
        next_token = None
        try:
            client = boto3.client('s3')
            while True:
                if next_token:
                    response = client.list_buckets(NextToken=next_token)
                else:
                    response = client.list_buckets()
                for reservation in response['Buckets']:
                        try:
                            bucket_size_in_bytes = 0
                            s3_tags = []
                            pub_response = client.get_public_access_block(Bucket=reservation['Name'])
                            if( pub_response['PublicAccessBlockConfiguration']):
                                status = pub_response['PublicAccessBlockConfiguration']['BlockPublicAcls'] &pub_response['PublicAccessBlockConfiguration']['IgnorePublicAcls'] & pub_response['PublicAccessBlockConfiguration']['BlockPublicPolicy'] & pub_response['PublicAccessBlockConfiguration']['RestrictPublicBuckets']
                            if(status==False):
                                bucket_access = "Public"
                            else:
                                bucket_access = "Not Public"
                            if 'Tags' in reservation:
                                s3_tags=[f"{tag['Key']}: {tag['Value']}" for tag in reservation['Tags']]
                        except botocore.exceptions.ClientError as e:
                                if 'NoSuchPublicAccessBlockConfiguration' in str(e):
                                    bucket_access = "Public"
                                elif 'AccessDenied' in str(e):
                                    bucket_access = "AccessDenied"
                                else:                            
                                    logging.error(
                                        f"Error in get_public_access_block for bucket: {reservation['Name']}: {str(e)}"
                                    )
                        try:
                            size_response = client.list_objects_v2(Bucket=reservation['Name'])
                            if 'Contents' in size_response:
                                bucket_size_in_bytes = sum(obj['Size'] for obj in size_response['Contents'])
                        except Exception as e:
                            logging.error(
                                f"Error in list_objects_v2: {reservation['Name']}: {str(e)}"
                            )
                        try:
                            if 'Tags' in reservation:
                                s3_tags=[f"{tag['Key']}: {tag['Value']}" for tag in reservation['Tags']]
                        except Exception as e:
                            logging.error(
                                f"Error in list_objects_v2: {str(e)}"
                            )
                        s3_list.append(
                            {
                                "name": reservation['Name'],
                                "storage in GB": bucket_size_in_bytes/1000/1024/1024,
                                "access": bucket_access,
                                "tags": s3_tags
                            }
                        )
                next_token = response.get('NextToken')
                if not next_token:
                    break
                    
        except Exception as e:
            logging.error(
                f"Error in get_s3_buckets_inventory: {str(e)}"
            )
        return s3_list
accountid=boto3.client('sts').get_caller_identity().get('Account')
awss3assets=AWSS3Assets(account_id=accountid)

s3_assets = [
    {
        "service": "S3",
        "friendlyname": "Simple Storage Service",
        "subservice": {
            "s3 buckets": awss3assets.get_s3_buckets_inventory()
        }
    }
]

print(json.dumps(s3_assets, indent=2))