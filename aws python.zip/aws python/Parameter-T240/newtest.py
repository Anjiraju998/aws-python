import boto3
import json
from datetime import datetime
import logging

class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()
        return json.JSONEncoder.default(self, o)
    
regions = ["ap-south-1"]
pr_list = []

for region in regions:
    client = boto3.client('ssm', region_name = region)
    par_des = client.describe_parameters()
    for parameters in par_des["Parameters"]:
        para_name = parameters["Name"]
        last = datetime.strftime(par_des["Parameters"][0]["LastModifiedDate"], '%Y-%m-%d'),
        parameters_gets = client.get_parameter_history(
            Name= para_name
            )
        for data in parameters_gets["Parameters"]:
            # creation_date = parameters_gets["Parameters"][0]['LastModifiedDate']
            # last = datetime.strftime(parameters["LastModifiedDate"], '%Y-%m-%d'), 
            pr_list.append({
                # "account": self.account_id,
                "region": region,
                "name" : para_name,
                "type" : parameters["Type"],
                "lastmodified" : datetime.strftime(par_des["Parameters"][0]["LastModifiedDate"], '%Y-%m-%d'),
                # "lastmodified" : last,
                "creation_date" : datetime.strftime(parameters_gets["Parameters"][0]['LastModifiedDate'], '%Y-%m-%d')
            })
    print(json.dumps(pr_list, indent=2, cls=DateTimeEncoder))