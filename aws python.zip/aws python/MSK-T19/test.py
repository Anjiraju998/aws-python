import boto3
from datetime import datetime, timedelta
import time
import json

class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()

        return json.JSONEncoder.default(self, o)
    
# def convert_bytes_to_mb(bytes_value):
#     return bytes_value / (1024 * 1024)
    
class AWS_KAFKA:
    def __init__(self):
        self.regions = ["ap-south-1"]
        # ec2_client = boto3.client('ec2', region_name="us-east-1")
        # region_response = ec2_client.describe_regions()
        # for reg in region_response["Regions"]:
        #   regions.append(reg["RegionName"])



    def aws_kafka(self):
        kafka_data_info = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('kafka', region_name= region )
                while True:
                    if next_token:
                        kafka_list = client.list_clusters(
                            nextToken = next_token)
                    else:
                        kafka_list = client.list_clusters()

                    for kafka in kafka_list["ClusterInfoList"]:
                        kafka_clt_arn = kafka["ClusterArn"]
                        print(kafka_clt_arn)
                        return
                        try:
                            kafka_des = client.describe_cluster(
                                ClusterArn = kafka_clt_arn
                            )
                            kafka_tags = {}
                            kafka_clt_data =  kafka_des["ClusterInfo"]
                            kafka_clt_name = kafka_clt_data["ClusterName"]
                            kafka_clt_ctn_datetime = kafka_clt_data["CreationTime"]
                            kafka_broker_count = kafka_clt_data["NumberOfBrokerNodes"]
                            kafka_clt_State = kafka_clt_data["State"]
                            kafka_clt_storage = kafka_clt_data["BrokerNodeGroupInfo"]
                            kafka_clt_tag = [kafka_tags.update({tag['Key']:tag['Value']}) for tag in kafka_clt_data["Tags"]]
                            kafka_clt_type = kafka_clt_data["BrokerNodeGroupInfo"]["InstanceType"]
                            kafka_storage = kafka_clt_data["BrokerNodeGroupInfo"]["StorageInfo"]["EbsStorageInfo"]["VolumeSize"]

                            kafka_data_info.append({
                                "kafka_clt_name" : kafka_clt_name,
                                "kafka_clt_arn" : kafka_clt_arn,
                                "kafka_clt_ctn_datetime" : kafka_clt_ctn_datetime,
                                "kafka_broker_count" : kafka_broker_count,
                                "kafka_clt_State" : kafka_clt_State,
                                "kafka_clt_type" : kafka_clt_type,
                                "kafka_storage" : kafka_storage,
                                "kafka_clt_tag" : kafka_clt_tag         
                                    
                                })  
                        except Exception as e:
                            print("kafka_des error", e)
                    next_token =  kafka_list.get("nextToken")
                    if not next_token:
                        break       
            except Exception as e:
                print("kafka_list error", e)
                
        return json.dumps(kafka_data_info, indent=2, cls= DateTimeEncoder)
    
kafka_info =  AWS_KAFKA()
print(kafka_info.aws_kafka())      