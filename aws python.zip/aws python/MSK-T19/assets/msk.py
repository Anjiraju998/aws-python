import boto3
from datetime import datetime, timedelta
import logging
import json

class AWSKafkaAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_kafka_inventory(self):
        kafka_data_info = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('kafka', region_name= region )
                while True:
                    if next_token:
                        kafka_list = client.list_clusters(
                            nextToken = next_token)
                    else:
                        kafka_list = client.list_clusters()
                    for kafka in kafka_list["ClusterInfoList"]:
                        kafka_des = client.describe_cluster(
                            ClusterArn = kafka["ClusterArn"]
                        )
                        kafka_tags = {}
                        cluster_data =  kafka_des["ClusterInfo"]
                        kafka_data_info.append({
                            "account": self.account_id,
                            "region": region,
                            "clustername" : cluster_data["ClusterName"],
                            "creationtime" : datetime.strftime(cluster_data["CreationTime"], '%Y-%m-%d'),
                            "brokercount" : cluster_data["NumberOfBrokerNodes"],
                            "state" :  cluster_data["State"],
                            "type" : cluster_data["BrokerNodeGroupInfo"]["InstanceType"],
                            "storage" : cluster_data["BrokerNodeGroupInfo"]["StorageInfo"]["EbsStorageInfo"]["VolumeSize"],
                            "tag" : [kafka_tags.update({tag['Key']:tag['Value']}) for tag in cluster_data["Tags"]]         
                                
                            })  
                    next_token =  kafka_list.get("nextToken")
                    if not next_token:
                        break       
            except Exception as e:
                logging.error(
                    f"Error in get_kafka_inventory for region {region}: {str(e)}"
                )
                continue 
        return kafka_data_info
    
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awskafkaassets=AWSKafkaAssets(account_id=accountid,regions=aws_regions)

kafka_assets = [
    {
        "service" : "msk",
        "friendlyname": "Amazon Managed Streaming for Apache Kafka",
        "subservice" : {
            "kafka cluster" : awskafkaassets.get_kafka_inventory()
        }
    }
]

print(json.dumps(kafka_assets, indent=2))
