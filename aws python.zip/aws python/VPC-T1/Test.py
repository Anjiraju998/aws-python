import boto3
import json
from datetime import datetime

class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()

        return json.JSONEncoder.default(self, o)


regions = ["ap-south-1"]

vpc_data= []

for region in regions:
    client = boto3.client('ec2', region_name =region)
try:
    vpcs= client.describe_vpcs()
    vpc_tags = {}
    cidr_states = {}

    for vpc in vpcs["Vpcs"]:
        vpc_id = vpc["VpcId"]
        vpc_cidr = vpc["CidrBlock"]
        # cidr_state = [cidr_states.update({"State":CidrBlockAssociationSet['CidrBlockState']['State']}) for CidrBlockAssociationSet in vpc["CidrBlockAssociationSet"]]
        cidr_state = [({"State":CidrBlockAssociationSet['CidrBlockState']['State']}) for CidrBlockAssociationSet in vpc["CidrBlockAssociationSet"]]
        vpc_tag = [vpc_tags.update({tag['Key']:tag['Value']}) for tag in vpc["Tags"]]

        vpc_data.append({
            "vpc_id" :  vpc_id,
            "vpc_cidr" : vpc_cidr,
            "vpc_tag" : vpc_tags,
            "cidr_state" : cidr_state
        })
except Exception as e:
        print("vpc error")
try:    
    igways = client.describe_internet_gateways()
    igway_data = []
    igw_tags = {}
    for igw in igways["InternetGateways"]:
        igw_id = igw["InternetGatewayId"]
        # igw_tag = [igw_tags.update({tag['Key']:tag['Value']}) for tag in igw["Tags"]]
        igw_tag = [igw_tags.update(f"\t{tag['Key']}: {tag['Value']}") for tag in igw["Tags"]]
        new_tag = list(igw_tags.items())
        for Attachment in igw["Attachments"]:
            att_vpcid = Attachment["VpcId"]
            att_state = Attachment["State"]
        # igw_vpc = [[Attachments["VpcId"][] for Attachments in igw["Attachments"]]
        # igw_state = [[Attachments["State"]] for Attachments in igw["Attachments"]]
            vpc_data.append({
                "igw_id" :  igw_id,
                "igw_tag" : new_tags,
                # "igw_vpc" : igw_vpc
                "att_vpcid" : att_vpcid,
                "att_state" : att_state
            })
except Exception as e:
        print("inernetgateway error")
# try:
#     endpoint_tags = {}
#     endpoints = client.describe_vpc_endpoints()
#     for endpoint in endpoints["VpcEndpoints"]:
#         vpc_endpoint = endpoint["VpcEndpointId"]
#         vpc_endpoint_type = endpoint["VpcEndpointType"]
#         endpoint_vpcid = endpoint["VpcId"]
#         endpoint_service = endpoint["ServiceName"]
#         endpoint_status = endpoint["State"]
#         endpoint_cretime = endpoint["CreationTimestamp"]
#         Pri_Dns_enabled = endpoint["PrivateDnsEnabled"]
#         Dns_Entries = endpoint["DnsEntries"]
#         endpoint_tag = [endpoint_tags.update({tag['Key']:tag['Value']}) for tag in endpoint["Tags"]]

    
#     vpc_data.append({
#         "vpc_endpoint" : vpc_endpoint,
#         "vpc_endpoint_type" : vpc_endpoint_type,
#         "endpoint_vpcid" : endpoint_vpcid,
#         "endpoint_service" : endpoint_service,
#         "endpoint_status" : endpoint_status,
#         "endpoint_cretime" : endpoint_cretime,
#         "Pri_Dns_enabled": Pri_Dns_enabled,
#         "Dns_Entries" : Dns_Entries,
#         "endpoint_tag" : endpoint_tag
        
#     })
# except Exception as e:
#     print("endpoint error")

# try:
#     nacl_tags = {}
#     net_acls = client.describe_network_acls()
#     for net_acl in net_acls["NetworkAcls"]:
#         network_acl_ID = net_acl["NetworkAclId"]
#         N_acl_vpc_id = net_acl["VpcId"]
#         for Associat in net_acl["Associations"]:
#             nacl_associate_id = Associat["NetworkAclAssociationId"] 
#         nacl_tag = [nacl_tags.update({tag["Key"]:tag["Value"]}) for tag in net_acl["Tags"]]
#         # print(nacl_associate_id)
#         vpc_data.append({
#             "network_acl_ID" : network_acl_ID,
#             "N_acl_vpc_id" : N_acl_vpc_id,
#             "nacl_associate_id" : nacl_associate_id,
#             "nacl_tag" : nacl_tags              
#              })
    
# except Exception as e:
#     print("Newwork_ACL error") 

# try:
#     p_list = []
#     vpcpeerings = client.describe_vpc_peering_connections()
#     for peerings in vpcpeerings['VpcPeeringConnections']:
#         p_list.append({
#             "region": region,
#             "vpcpeeringconnectionid" : peerings['VpcPeeringConnectionId'],
#             "acceptercidrblock" : peerings['AccepterVpcInfo']['CidrBlock'],
#             "accepterownerid" : peerings['AccepterVpcInfo']['OwnerId'],
#             "acceptervpcid" : peerings['AccepterVpcInfo']['VpcId'],
#             "accepterregion" : peerings['AccepterVpcInfo']['Region'],
#             "requestercidrblock" : peerings["RequesterVpcInfo"]["CidrBlock"],
#             "requesterownerid" : peerings["RequesterVpcInfo"]["OwnerId"],
#             "requestervpcid" : peerings["RequesterVpcInfo"]["VpcId"],
#             "requesterregion" : peerings["RequesterVpcInfo"]["Region"],
#             "status" : peerings["Status"]["Code"],
#             "tags" : [({tag['Key']:tag['Value']}) for tag in vpc["Tags"]]  if "Tags" in vpc else None ,
#             })     
#     # print(p_list)
# except Exception as e:
#     print("Newwork_ACL error", e)

    
print(json.dumps(vpc_data, indent=2, cls= DateTimeEncoder))