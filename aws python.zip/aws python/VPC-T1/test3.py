import boto3
import json
from datetime import datetime
import logging

class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()
        return json.JSONEncoder.default(self, o)

class AWSVpcAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_internetgateway_inventory(self):
        igway_list = []
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region)    
                igways = client.describe_internet_gateways()
                for igw in igways["InternetGateways"]:
                    for Attachment in igw["Attachments"]:
                        igway_list.append({
                            "account": self.account_id,
                            "region": region,
                            "igwid" :  igw["InternetGatewayId"],
                            "igwtag" : [({tag['Key']:tag['Value']}) for tag in igw["Tags"]],
                            "attachmentvpcid" : Attachment["VpcId"],
                            "attachmentstate" : Attachment["State"]
                        })
            except Exception as e:
                logging.error(
                    f"Error in get_internetgateway_inventory for region {region}: {str(e)}"
                )
                continue
        return igway_list
    def get_endpoint_inventory(self):
        endpoint_list = []
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region)
                endpoints = client.describe_vpc_endpoints()
                for endpoint in endpoints["VpcEndpoints"]:                
                    endpoint_list.append({
                        "account": self.account_id,
                        "region": region,
                        "vpc_endpoint" : endpoint["VpcEndpointId"],
                        "vpcendpointtype" : endpoint["VpcEndpointType"],
                        "endpointvpcid" : endpoint["VpcId"],
                        "endpointservice" : endpoint["ServiceName"],
                        "endpointstatus" : endpoint["State"],
                        "endpointcretime" : endpoint["CreationTimestamp"],
                        "tag" : [({tag['Key']:tag['Value']}) for tag in endpoint["Tags"]] 
                    })
            except Exception as e:
                logging.error(
                    f"Error in get_endpoint_inventory for region {region}: {str(e)}"
                )
                continue
        return endpoint_list
    def get_networkacl_inventory(self):
        nacl_list = []
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region)
                net_acls = client.describe_network_acls()
                for net_acl in net_acls["NetworkAcls"]:
                    for Associat in net_acl["Associations"]:
                        nacl_list.append({
                            "account": self.account_id,
                            "id" : net_acl["NetworkAclId"],
                            "vpcid" : net_acl["VpcId"],
                            "tag" : [({tag["Key"]:tag["Value"]}) for tag in net_acl["Tags"]]              
                            })   
            except Exception as e:
                logging.error(
                    f"Error in get_networkacl_inventory for region {region}: {str(e)}"
                )
                continue
        return nacl_list
    def get_vpc_peering_inventory(self):
        vpcpeering_list = []
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region) 
                vpcpeerings = client.describe_vpc_peering_connections()
                for peerings in vpcpeerings['VpcPeeringConnections']:
                    vpcpeering_list.append({
                        "account": self.account_id,
                        "region": region,
                        "vpcpeeringconnectionid" : peerings['VpcPeeringConnectionId'],
                        "acceptercidrblock" : peerings['AccepterVpcInfo']['CidrBlock'],
                        "accepterownerid" : peerings['AccepterVpcInfo']['OwnerId'],
                        "acceptervpcid" : peerings['AccepterVpcInfo']['VpcId'],
                        "accepterregion" : peerings['AccepterVpcInfo']['Region'],
                        "requestercidrblock" : peerings["RequesterVpcInfo"]["CidrBlock"],
                        "requesterownerid" : peerings["RequesterVpcInfo"]["OwnerId"],
                        "requestervpcid" : peerings["RequesterVpcInfo"]["VpcId"],
                        "requesterregion" : peerings["RequesterVpcInfo"]["Region"],
                        "status" : peerings["Status"]["Code"],
                        "tags" : [({tag['Key']:tag['Value']}) for tag in peerings["Tags"]]  if "Tags" in peerings else None 
                        })       
            except Exception as e:
                logging.error(
                    f"Error in get_vpc_peering_inventory for region {region}: {str(e)}"
                )
                continue
        return vpcpeering_list

ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awsvpcassets=AWSVpcAssets(account_id=accountid,regions=aws_regions)  

vpc_assets = [
    {
        "service" : "vpc",
        "friendlyname": "Virtual Private Cloud",
        "subservice" : {
            "Internetgateway" : awsvpcassets.get_internetgateway_inventory(),
            "endpoint" : awsvpcassets.get_endpoint_inventory(),
            "networkacl" : awsvpcassets.get_networkacl_inventory(),
            "peering" : awsvpcassets.get_vpc_peering_inventory()
        }
    }
]

print(json.dumps(vpc_assets, indent=2))

print(json.dumps(vpc_assets, indent=2, cls=DateTimeEncoder))