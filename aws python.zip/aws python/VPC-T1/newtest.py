import boto3
import json
from datetime import datetime
import logging

class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()
        return json.JSONEncoder.default(self, o)

class AWSVpcAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_internetgateway_inventory(self):
        igway_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region)
                while True:
                    if next_token:
                        igways = client.describe_internet_gateways(
                            next_token = next_token
                        )
                    else:   
                        igways = client.describe_internet_gateways()
                    for igw in igways["InternetGateways"]:
                        for Attachment in igw["Attachments"]:
                            igway_list.append({
                                "igw_id" :  igw["InternetGatewayId"],
                                "region": region,
                                "tag" : [({tag['Key']:tag['Value']}) for tag in igw["Tags"]],
                                "att_vpcid" : Attachment["VpcId"],
                                "att_state" : Attachment["State"]
                            })
                    next_token = igways.get("next_token")
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_internetgateway_inventory for region {region}: {str(e)}"
                )
                continue
        return igway_list
    def get_endpoint_inventory(self):
        endpoint_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region)
                while True:
                    if next_token:
                        endpoints = client.describe_vpc_endpoints(
                            next_token = next_token
                        )
                    else:
                        endpoints = client.describe_vpc_endpoints()
                    for endpoint in endpoints["VpcEndpoints"]: 
                        if 'Tags' in endpoint:
                            tag = [f"{tag['Key']:tag['Value']}" for tag in endpoint["Tags"]]
                        endpoint_list.append({
                            "vpc_endpoint" : endpoint["VpcEndpointId"],
                            "region": region,
                            "vpc_endpoint_type" : endpoint["VpcEndpointType"],
                            "endpoint_vpcid" : endpoint["VpcId"],
                            "endpoint_service" : endpoint["ServiceName"],
                            "status" : endpoint["State"],
                            "creationtime" : endpoint["CreationTimestamp"],
                            # "tag" : [({tag['Key']:tag['Value']}) for tag in endpoint["Tags"]]
                            tag : tag
                        })
                    next_token = endpoints.get("next_token")
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_endpoint_inventory for region {region}: {str(e)}"
                )
                continue
        return endpoint_list
    def get_networkacl_inventory(self):
        nacl_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region)
                while True:
                    if next_token:
                        net_acls = client.describe_network_acls(
                            next_token = next_token
                        )
                    else:
                        net_acls = client.describe_network_acls()
                    for net_acl in net_acls["NetworkAcls"]:
                        for Associat in net_acl["Associations"]:
                            nacl_list.append({
                                "ID" : net_acl["NetworkAclId"],
                                "netaclvpcid" : net_acl["VpcId"],
                                "tag" : [({tag["Key"]:tag["Value"]}) for tag in net_acl["Tags"]]              
                                })  
                    next_token = net_acls.get("next_token")
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_networkacl_inventory for region {region}: {str(e)}"
                )
                continue
        return nacl_list
    def get_vpc_peering_inventory(self):
        vpcpeering_list = []
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name =region) 
                vpcpeerings = client.describe_vpc_peering_connections()
                for peerings in vpcpeerings['VpcPeeringConnections']:
                    vpcpeering_list.append({
                        "account": self.account_id,
                        "region": region,
                        "vpcpeeringconnectionid" : peerings['VpcPeeringConnectionId'],
                        "acceptercidrblock" : peerings['AccepterVpcInfo']['CidrBlock'],
                        "accepterownerid" : peerings['AccepterVpcInfo']['OwnerId'],
                        "acceptervpcid" : peerings['AccepterVpcInfo']['VpcId'],
                        "accepterregion" : peerings['AccepterVpcInfo']['Region'],
                        "requestercidrblock" : peerings["RequesterVpcInfo"]["CidrBlock"],
                        "requesterownerid" : peerings["RequesterVpcInfo"]["OwnerId"],
                        "requestervpcid" : peerings["RequesterVpcInfo"]["VpcId"],
                        "requesterregion" : peerings["RequesterVpcInfo"]["Region"],
                        "status" : peerings["Status"]["Code"],
                        "tags" : [({tag['Key']:tag['Value']}) for tag in peerings["Tags"]]  if "Tags" in peerings else None 
                        })       
            except Exception as e:
                logging.error(
                    f"Error in get_vpc_peering_inventory for region {region}: {str(e)}"
                )
                continue
        return vpcpeering_list

ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awsvpcassets=AWSVpcAssets(account_id=accountid,regions=aws_regions)  

vpc_assets = [
    {
        "service" : "acm",
        "subservice" : {
            "projects" : { 
                "Internetgateway" : awsvpcassets.get_internetgateway_inventory(),
                "endpoint" : awsvpcassets.get_endpoint_inventory(),
                "networkacl" : awsvpcassets.get_networkacl_inventory(),
                "peering" : awsvpcassets.get_vpc_peering_inventory()         
            }
        }
    }
]

print(json.dumps(vpc_assets, indent=2, cls=DateTimeEncoder))