import boto3
from datetime import datetime, timezone 
import logging
import json

regions = ["ap-south-1"]
opensearch_data = []
for region in regions:
    client = boto3.client('opensearch', region_name = region)
    opensearchl_list = client.list_domain_names()
for opensearch in opensearchl_list["DomainNames"]:
    opensearch_des = client.describe_domains(
    DomainNames= [opensearch["DomainName"]]
    )
    for opensearch in opensearch_des["DomainStatusList"]:
        EngineVersion = opensearch["EngineVersion"]
        InstanceType = opensearch["ClusterConfig"]["InstanceType"]
        InstanceCount = opensearch["ClusterConfig"]["InstanceCount"]
        # DedicatedMasterType = opensearch["ClusterConfig"]["DedicatedMasterType"]
        # DedicatedMasterCount = opensearch["ClusterConfig"]["DedicatedMasterCount"]
        EBSEnabled = opensearch["EBSOptions"]["EBSEnabled"]
        VolumeType = opensearch["EBSOptions"]["VolumeType"]
        VolumeSize = opensearch["EBSOptions"]["VolumeSize"]
        CurrentVersion = opensearch["ServiceSoftwareOptions"]["CurrentVersion"]
        print(EngineVersion)
        print(InstanceType)
        print(InstanceCount)
        # print(DedicatedMasterType)
        # print(DedicatedMasterCount)
        print(EBSEnabled)
        print(VolumeType)
        print(VolumeSize)
        print(CurrentVersion)
        # print(InstanceCount)
        # print(InstanceCount)
   