import boto3
import json
import logging

class AwsCloudTrailAssets:    
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    
    def get_cloudtrail_inventory(self):   
        next_token = None 
        cloudtrail_list = []
        for region in self.regions:
            try:
                client = boto3.client('cloudtrail', region_name=region)
                while True:
                    if next_token:       
                        response = client.describe_trails(
                            nextToken = next_token
                        )
                    else:   
                        response = client.describe_trails() 
                        for trail in response['trailList']:
                            if not any(t['name'] == trail['Name'] and t['ismultiregiontrail'] == trail['IsMultiRegionTrail'] for t in cloudtrail_list):
                                cloudtrail_list.append({
                                    'account'                       : self.account_id,
                                    'region'                        : region,
                                    'name'                          : trail['Name'],
                                    's3bucketname'                  : trail['S3BucketName'],
                                    'logfilevalidationenabled'      : trail['LogFileValidationEnabled'],
                                    'cloudwatchLogsloggrouparn'     : trail['CloudWatchLogsLogGroupArn'],
                                    'includeglobalserviceevents'    : trail['IncludeGlobalServiceEvents'],
                                    'ismultiregiontrail'            : trail['IsMultiRegionTrail']
                                })
                    next_token = response.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_cloudtrail_inventory for region {region}: {str(e)}"
                )
                continue   
        return cloudtrail_list
    
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')      
    
AwsCloudTrailAssets =  AwsCloudTrailAssets(account_id=accountid, regions=aws_regions)

AwsCloudTrail_Assets = [
    {
        "service"      : "CloudTrail",
        "friendlyname" : "CloudTrail",
        "subservice"   : {
            "trails"   : AwsCloudTrailAssets.get_cloudtrail_inventory()
        }
    }
]    
print(json.dumps(AwsCloudTrail_Assets, indent=2))
