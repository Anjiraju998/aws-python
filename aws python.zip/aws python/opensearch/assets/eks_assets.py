import boto3
import json
from datetime import datetime,timezone
import logging

class AWSEksAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id
    
    def get_eks_cluster_assets(self):
        cluster_output =[]
        next_token= None
        for region in self.regions:
            try:
                eks_client = boto3.client('eks', region_name= region)   
                while True:
                    if next_token : eks_cluster_response = eks_client.list_clusters(nextToken = next_token)
                    else: eks_cluster_response = eks_client.list_clusters()
                    for cluster in eks_cluster_response['clusters']:
                        cluster_reponse = eks_client.describe_cluster(name = cluster)
                        cluster_data = cluster_reponse['cluster']

                        cluster_output.append({
                            'account_id'  : self.account_id,
                            'region'      : region,                            
                            'eks_cluster' : cluster,
                            'created_on'  : datetime.strftime(cluster_data['createdAt'], '%Y-%m-%d'),
                            'version'     : cluster_data['version']
                        })

                    next_token = eks_cluster_response.get('nextToken')
                    if not next_token:break

            except Exception as e:
                logging.error(f"Error in EKS clusters for region {region}: {str(e)}" )
        return cluster_output
    
    def get_node_groups_assets(self,clusters):
        ng_output =[]
        ng_next_token= None
        for region in self.regions:
            for cluster in clusters:
                try:
                    eks_client = boto3.client('eks', region_name= region)  
                    while True:
                        if ng_next_token : 
                            NG_List_response = eks_client.list_nodegroups(
                                                            clusterName = cluster['eks_cluster'], 
                                                            nextToken = ng_next_token)
                        else: NG_List_response = eks_client.list_nodegroups(clusterName = cluster['eks_cluster'])

                        if NG_List_response['nodegroups']:
                            for ng in NG_List_response['nodegroups']:
                                describe_ng = eks_client.describe_nodegroup(
                                                clusterName   = cluster['eks_cluster'],
                                                nodegroupName = ng)
                                
                                ng_data = describe_ng['nodegroup']
                                ng_output.append({
                                    'account_id'      : self.account_id,
                                    'region'          : region,
                                    'cluster'         : cluster['eks_cluster'],
                                    'node_group'      : ng ,
                                    'ng_created_date' : datetime.strftime(ng_data['createdAt'], '%Y-%m-%d') if 'createdAt' in ng_data else None,
                                    'ng_modified_at'  : datetime.strftime(ng_data['modifiedAt'], '%Y-%m-%d') if 'modifiedAt' in ng_data else None,
                                    'ng_status'       : ng_data['status'] if 'status' in ng_data else None,
                                    'min_nodes'       : ng_data['scalingConfig']['minSize'] ,
                                    'max_nodes'       : ng_data['scalingConfig']['maxSize'] ,
                                    'desired_nodes'   : ng_data['scalingConfig']['desiredSize'] ,
                                })
                        
                        ng_next_token = NG_List_response.get('nextToken')
                        if not ng_next_token : break

                except Exception as e:
                    logging.error(f"Error in getting node-groups in EKS clusters {cluster['eks_cluster']} for region {region}: {str(e)}" )
        return ng_output
            

    def get_cluster_addons(self , clusters):
        addon_output =[]
        addon_next_token= None
        for region in self.regions:
            for cluster in clusters:
                try:
                    eks_client = boto3.client('eks', region_name= region)  
                    while True:
                        if addon_next_token :   
                            list_addons = eks_client.list_addons( 
                                clusterName = cluster['eks_cluster'],
                                nextToken = addon_next_token 
                            )
                        else: 
                            list_addons = eks_client.list_addons( clusterName = cluster['eks_cluster']) 
                        
                        for addon in list_addons['addons']:
                            addon_config = eks_client.describe_addon(
                                        clusterName = cluster['eks_cluster'],
                                        addonName = addon)
                            addon_data = addon_config['addon']
                            
                            addon_output.append({
                                'account_id'    : self.account_id,
                                'region'        : region,
                                'eks_cluster'   : cluster['eks_cluster'],
                                'addon_name'    : addon_data['addonName'] if 'addonName' in addon_data else None,
                                'addonVersion'  : addon_data['addonVersion'] if 'addonVersion' in addon_data else None,
                            })

                        addon_next_token = list_addons.get('nextToken')
                        if not addon_next_token : break
                        
                except Exception as e:
                    logging.error(f"Error for add-ons in EKS clusters {cluster['eks_cluster']} for region {region}: {str(e)}" )
            
        return addon_output                    


ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

AwsEKSAssets=AWSEksAssets(account_id=accountid,regions=aws_regions)
clusters = AwsEKSAssets.get_eks_cluster_assets()

eks_assets = [
    {
        "service"       : 'EKS',
        "friendly_name" : 'Elastic Kubernetes Service',
        "subservices": {
        "clusters": clusters,
        "node_groups" : AwsEKSAssets.get_node_groups_assets(clusters),
        "add_ons" : AwsEKSAssets.get_cluster_addons(clusters)
        }    
    }
]

print(json.dumps(eks_assets,indent=2))