import boto3
import logging
import json
from datetime import datetime

class AWSCodeBuildAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id
    def get_codebuild_projects_inventory(self):
        codebuild_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('codebuild', region_name=region)
                codebuild_projects = []
                while True:
                    params = {'nextToken': next_token} if next_token else {}
                    projects_list_response = client.list_projects(**params)
                    codebuild_projects=codebuild_projects+projects_list_response['projects']
                    next_token = projects_list_response.get('NextToken')
                    if not next_token:
                        break
                if len(codebuild_projects) > 0:
                    projects_get_response = client.batch_get_projects(names=codebuild_projects)
                    for project in projects_get_response['projects']:
                        response = client.list_builds_for_project(
                            projectName=project['name'],
                            sortOrder='DESCENDING'
                        )
                        if response['ids']:
                            projects_build_response = client.batch_get_builds(ids=[response['ids'][0]])
                            lastrundate = datetime.strftime(projects_build_response['builds'][0]['startTime'], '%Y-%m-%d')
                        else:
                            lastrundate = "-"
                        codebuild_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "name": project['name'],
                                "source": project['source']['type'],
                                "creationdate": datetime.strftime(project['created'], '%Y-%m-%d'),
                                "lastmodifieddate": datetime.strftime(project['lastModified'], '%Y-%m-%d'),
                                "lastrundate": lastrundate
                            }
                        )   
            except Exception as e:
                logging.error(
                    f"Error in get_codebuild_projects_inventory for region {region}: {str(e)}"
                )
                continue
        return codebuild_list


ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awscodebuildassets=AWSCodeBuildAssets(account_id=accountid,regions=aws_regions)
codebuild_assets = [
    {
        "service": "CodeBuild",
        "friendlyname": "CodeBuild",
        "subservice": {
            "projects": awscodebuildassets.get_codebuild_projects_inventory()
        }
    }
]

print(json.dumps(codebuild_assets))