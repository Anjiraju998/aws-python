import boto3
import json
import logging
from datetime import datetime

class AWSCodePipelineAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id = account_id
        self.clients = {region: boto3.client('codepipeline', region_name=region) for region in regions}

    def get_codepipeline_projects_inventory(self):
        codepipeline_list = []
        for region, client in self.clients.items():
            try:
                next_token = None
                while True:
                    params = {'nextToken': next_token} if next_token else {}
                    codepipeline_list_response = client.list_pipelines(**params)
                    next_token = codepipeline_list_response.get('NextToken')
                    pipelines_info = self._get_pipeline_details(client, codepipeline_list_response['pipelines'], region)
                    codepipeline_list.extend(pipelines_info)
                    if not next_token:
                        break
            except Exception as e:
                logging.error(f"Error in get_codepipeline_projects_inventory for region {region}: {str(e)}")
        return codepipeline_list

    def _get_pipeline_details(self, client, pipelines, region):
        pipelines_info = []
        for pipeline in pipelines:
            try:
                pipeline_details = client.get_pipeline(name=pipeline['name'])
                executions = client.list_pipeline_executions(pipelineName=pipeline['name'])
                last_execution_date = self._get_last_execution_date(executions)
                stages_info = self._get_stages_info(pipeline_details)
                pipelines_info.append(
                    {
                        "account": self.account_id,
                        "region": region,
                        "name": pipeline['name'],
                        "pipelineType": pipeline.get('pipelineType', '-'),
                        "creationdate": datetime.strftime(pipeline['created'], '%Y-%m-%d'),
                        "lastexectiondate": last_execution_date,
                        **stages_info,
                    }
                )
            except Exception as e:
                logging.error(f"Error getting details for pipeline {pipeline['name']} in region {region}: {str(e)}")
        return pipelines_info

    def _get_last_execution_date(self, executions):
        if executions['pipelineExecutionSummaries']:
            start_time = executions['pipelineExecutionSummaries'][0].get('startTime')
            if start_time:
                return datetime.strftime(start_time, '%Y-%m-%d')
        return "-"

    def _get_stages_info(self, pipeline_details):
        sourceprovider = sourcerepo = codebuild = codedeploy = "-"
        for stage in pipeline_details['pipeline']['stages']:
            for action in stage['actions']:
                category = action['actionTypeId']['category']
                if category == 'Source':
                    sourceprovider = action['actionTypeId']['provider']
                    repo_info, branch_name = self._get_repo_info(action)
                    sourcerepo = f"{repo_info}/{branch_name}" if repo_info else "-"
                elif category == 'Build':
                    codebuild = action['configuration'].get('ProjectName', '-')
                elif category == 'Deploy':
                    codedeploy = self._get_deploy_info(action)
        return {"sourceprovider": sourceprovider, "sourcerepo": sourcerepo, "codebuild": codebuild, "codedeploy": codedeploy}

    def _get_repo_info(self, action):
        repo_info = action['configuration'].get('RepositoryName', '') or action['configuration'].get('FullRepositoryId', '')
        branch_name = action['configuration'].get('BranchName', '-')
        return repo_info, branch_name

    def _get_deploy_info(self, action):
        app_name = action['configuration'].get('ApplicationName', '-')
        deploy_group = action['configuration'].get('DeploymentGroupName', '-')
        return f"{app_name}/{deploy_group}" if app_name != '-' else "-"

if __name__ == "__main__":
    ec2_client = boto3.client('ec2', region_name="us-east-1")
    aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
    account_id = boto3.client('sts').get_caller_identity().get('Account')

    aws_codepipeline_assets = AWSCodePipelineAssets(account_id=account_id, regions=aws_regions)
    print(json.dumps(aws_codepipeline_assets.get_codepipeline_projects_inventory(), indent=4))
