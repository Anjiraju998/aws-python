import boto3
import json
import logging
from datetime import datetime

class AwsRDSAssets:    
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_rds_inventory(self):
        next_token = None
        rds_instances = []    
        
        for region in self.regions:
            try:
                client = boto3.client('rds', region_name=region)
                while True:
                    if next_token:
                        list_response = client.describe_db_instances(
                            nextToken = next_token
                        )
                    else:
                        list_response = client.describe_db_instances()    
                        for instances in list_response['DBInstances']:
                            rds_instances.append({
                                "account"              : self.account_id,
                                "region"               : region,
                                'instancename'         : instances['DBInstanceIdentifier'],
                                'engine'               : instances['Engine'],
                                'status'               : instances['DBInstanceStatus'],
                                'instanceclass'        : instances['DBInstanceClass'],
                                'masterusername'       : instances['MasterUsername'],
                                'allocatedstorage'     : instances['AllocatedStorage'],
                                'dbname'               : instances.get('DBName', 'N/A'),
                                'subnetgroup'        : instances['DBSubnetGroup']['DBSubnetGroupName'],
                                'multiaz'              : instances['MultiAZ']
                            })
                    next_token = list_response.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_rds_inventory for region {region}: {str(e)}"
                )
                continue 
        return rds_instances
    
    def get_rds_subnetgroups_inventory(self):
        db_subnet_group_list = []
        next_token = None
        for region in self.regions:
                try:
                    client = boto3.client('rds', region_name=region)
                    while True:
                        if next_token:
                            db_sg_response = client.describe_db_subnet_groups(NextToken=next_token)
                        else:    
                            db_sg_response = client.describe_db_subnet_groups()
                            for db_sg in db_sg_response['DBSubnetGroups']:
                                db_subnet_group_list.append({
                                    'name'              : db_sg['DBSubnetGroupName'],
                                    'vpcid'             : db_sg['VpcId'],
                                    'subnets'           : [subnet['SubnetIdentifier'] for subnet in db_sg['Subnets']]
                                })
                        next_token = db_sg_response.get('nextToken')
                        if not next_token:
                            break
                except Exception as e:
                    logging.error(
                        f"Error in get_rds_subnetgroups_inventory for region {region}: {str(e)}"
                    )
                    continue 
                return db_subnet_group_list
            
    def get_rds_snapshots_inventory(self):
        snapshots_list = []
        next_token = None
        for region in self.regions:
                    try:
                        client = boto3.client('rds', region_name=region)
                        while True:
                            if next_token:
                                response = client.describe_db_snapshots(NextToken=next_token)
                            else:    
                                response = client.describe_db_snapshots()
                                for snapshots in response['DBSnapshots']:
                                    snapshots_list.append({
                                        'name'                 : snapshots['DBSnapshotIdentifier'],
                                        'instancename'         : snapshots['DBInstanceIdentifier'],
                                        'snapshotcreatetime'   : datetime.strftime(snapshots['SnapshotCreateTime'], '%Y-%m-%d'),
                                        'allocatedstorage'     : snapshots['AllocatedStorage'],
                                        'status'               : snapshots['Status']
                                        
                                    })
                                    
                            next_token = response.get('nextToken')
                            if not next_token:
                                break
                    except Exception as e:
                        logging.error(
                            f"Error in get_rds_snapshots_inventory for region {region}: {str(e)}"
                        )
                        continue 
                    return snapshots_list           
        


ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')   

rdsinstancesassets =  AwsRDSAssets(account_id=accountid, regions=aws_regions)

rds_instances_assets = [
    {
        "service" : "RDS",
        "friendlyname" : "Amazon Relational Database Service",
        "subservice" : {
            "instances" : rdsinstancesassets.get_rds_inventory(),
            "subnetgroups" : rdsinstancesassets.get_rds_subnetgroups_inventory(),
            "snapshots"   : rdsinstancesassets.get_rds_snapshots_inventory()
        }
    }
]     
                        
print(json.dumps(rds_instances_assets, indent=2))