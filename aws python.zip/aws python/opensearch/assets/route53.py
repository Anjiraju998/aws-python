import boto3
import logging
import json

class AwsRoute53Assets:    
    def __init__(self, account_id):
        self.account_id= account_id
        
    def get_route53_inventory(self):
        next_token = None
        hostedzone = []     
        try:
            client = boto3.client('route53', region_name= "us-east-1")
            while True:
                if next_token:
                    HostedZone_response = client.list_hosted_zones(nextToken = next_token)
                else:    
                    HostedZone_response = client.list_hosted_zones()
                for zones in HostedZone_response["HostedZones"]:
                    hostedzone.append({
                        'id'                     : zones['Id'],
                        'name'                   : zones['Name'],
                        'resourcerecordsetcount' : zones['ResourceRecordSetCount'],
                        'privatezone'            : zones['Config']['PrivateZone']
                    })
                next_token = HostedZone_response.get('nextToken')
                if not next_token:
                    break
        except Exception as e:
            logging.error(
                f"Error in get_route53_inventory: {str(e)}"
            )
        return hostedzone

AwsRoute53Assets =  AwsRoute53Assets(account_id="accountid")

AwsRoute53_Assets = [
    {
        "service" : "route53",
        "friendlyname" : "route53",
        "subservice" : {
            "hostedzone" : AwsRoute53Assets.get_route53_inventory()
        }
    }
]
print(json.dumps(AwsRoute53_Assets, indent=3))