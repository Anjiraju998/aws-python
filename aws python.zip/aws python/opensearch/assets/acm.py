import boto3
import logging
import json
from datetime import datetime

class AWSAcmAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id

    def get_acm_inventory(self):
        next_token = None
        acm_list= [] 
        for region in self.regions:
            try:
                client = boto3.client('acm', region_name= region) 
                while True:
                    params = {'nextToken': next_token} if next_token else {}
                    acm_lists = client.list_certificates(**params)
                    for acm in acm_lists["CertificateSummaryList"]:        
                        acm_des = client.describe_certificate(
                            CertificateArn= acm["CertificateArn"]
                        )
                        acm_list.append({
                            "account": self.account_id,
                            "region": region,
                            "domain_name" : acm_des["Certificate"]["DomainName"],
                            "sub_alt_name" : [subdomain for subdomain in acm_des["Certificate"]["SubjectAlternativeNames"] if subdomain != acm_des["Certificate"]["DomainName"]],
                            "acm_Status" : acm_des["Certificate"]["Status"],
                            "acm_inuseby"  : acm_des["Certificate"]["InUseBy"],
                            "acm_IssuedAt" : datetime.strftime(acm_des["Certificate"]["IssuedAt"], '%Y-%m-%d'),
                            "expirydate" : datetime.strftime(acm_des["Certificate"]["NotAfter"], '%Y-%m-%d')                                   
                        })
                    
                    next_token =  acm_lists.get('nextToken')  
                    if not next_token:
                        break                        
            except Exception as e:
                logging.error(
                    f"Error in get_acm_inventory for region {region}: {str(e)}"
                )
                continue                   
        return acm_list
    
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awsacmassets=AWSAcmAssets(account_id=accountid,regions=aws_regions)

acm_assets = [
    {
        "service" : "acm",
        "subservice" : {
            "projects" : awsacmassets.get_acm_inventory()
        }
    }
]

print(json.dumps(acm_assets))

