import boto3
import json
from datetime import datetime,timezone
import logging

class AWSElasticCacheAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id
    
    def Get_Elastic_Cache_ASSETS(self):
        cache_assets =[]
        for region in self.regions:
            try:
                ec_client = boto3.client('elasticache', region_name= region)
                cache_response = ec_client.describe_cache_clusters()
                for ec in cache_response['CacheClusters'] :

                    cache_assets.append({
                        'account_id'    : self.account_id,
                        'region'        : region,
                        'Cluster_Name'  : ec['ReplicationGroupId'],
                        'node_name'     : ec['CacheClusterId'],
                        'no_of_nodes'   : ec['NumCacheNodes'],
                        'Node_type'     : ec['CacheNodeType'],
                        'EngineVersion' : ec['EngineVersion'],
                        'CreatedDate'   : datetime.strftime(ec['CacheClusterCreateTime'], '%Y-%m-%d'),
                    })

            
            except Exception as e:
                logging.error(f"Error in Elastic Cache clusters for region {region}: {str(e)}" )
        return cache_assets



ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

AwsCacheAssets=AWSElasticCacheAssets(account_id=accountid,regions=aws_regions)
Cache_assets = [
    {
        "service": "Elastic Cache",
        "friendlyname": "Elastic Cache",
        "subservices": {
            "clusters": AwsCacheAssets.Get_Elastic_Cache_ASSETS()
        }
    }
]

print(json.dumps(Cache_assets,indent=2))
