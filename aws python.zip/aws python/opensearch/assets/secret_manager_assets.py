import boto3
import json
from datetime import datetime,timezone
import logging


class AWSSecretsManagerAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id

    def get_secrets(self):
        next_token = None
        output =[]
        for region in self.regions:
            try:
                region_client = boto3.client('secretsmanager', region_name=region)
                while True:
                    if next_token:
                        secrets_client_response =region_client.list_secrets(NextToken=next_token)
                    else:
                        secrets_client_response =region_client.list_secrets(
                            IncludePlannedDeletion = True,
                        )
                    for res in secrets_client_response['SecretList']:

                        output.append({
                            "account"           : self.account_id,
                            "region"            : region,                    
                            "name"              : res['Name'],
                            "created_date"       : datetime.strftime(res.get('CreatedDate'), '%Y-%m-%d'),
                            "last_accessed"      : datetime.strftime(res.get('LastAccessedDate'),'%Y-%m-%d') if 'LastAccessedDate' in res else None,
                            "last_changed_date"   : datetime.strftime(res.get('LastChangedDate'), '%Y-%m-%d')if 'LastChangedDate' in res else None,
                            "rotation_enabled"   : res.get('RotationEnabled'),
                            })                            
                    next_token = secrets_client_response.get('NextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(f"Error in getting secrets for region {region}: {str(e)}" )
            
        return output
        

ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

secret_assets= AWSSecretsManagerAssets(account_id=accountid,regions=aws_regions)

secret_assets=[{
    "service"      :  "Secrets Manager",
    "friendly name" : "Secrets Manager",
    "subservices"   :  {
        'secrets':  secret_assets.get_secrets(),
        }
}]

print(json.dumps(secret_assets,indent=2))