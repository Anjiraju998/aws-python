import boto3
import json
from datetime import datetime,timezone
import logging

class ECR_ASSETS:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id
    
    def ECR_ASSETS(self):
        
        ecr_assets_output =[]
        next_token= None
        for region in self.regions:
            try:
                ecr_client = boto3.client('ecr', region_name= region)
                while True:
                    if next_token: ecr_repo_response = ecr_client.describe_repositories(nextToken=next_token)
                    else: ecr_repo_response = ecr_client.describe_repositories()
                    for repo in ecr_repo_response['repositories']:
                        output_images =[]
                        image_next_token = None
                        while True:
                            if image_next_token: 
                                ecr_image_response = ecr_client.describe_repositories(
                                    repositoryName=repo['repositoryName'],
                                    nextToken=next_token
                                )
                            else : 
                                ecr_image_response = ecr_client.describe_images(repositoryName=repo['repositoryName'])
                            for image in ecr_image_response['imageDetails'] :

                                output_images.append({
                                    'image_Digest'       : image['imageDigest'],
                                    'images_pushed_date' :  image['imagePushedAt']
                                })
                            output_images.sort(key=lambda x: x['images_pushed_date'])                  


                            image_next_token = ecr_image_response.get('NextToken')
                            if not image_next_token:
                                break                                    

                        latest_image_digest = output_images[-1].get('image_Digest')
                        latest_images_pushed_date = output_images[-1].get('images_pushed_date')

                        ecr_assets_output.append({
                            'account_id'  : self.account_id,
                            'region'      : region ,
                            'repo_name'   : repo['repositoryName'],
                            'created_on'  : datetime.strftime(repo['createdAt'], '%Y-%m-%d'),
                            'latest_image_digest' : latest_image_digest,
                            'latest_images_pushed_date' : datetime.strftime(latest_images_pushed_date, '%Y-%m-%d'),
                        })
                    
                    next_token = ecr_repo_response.get('NextToken')
                    if not next_token:
                        break
            
            except Exception as e:
                logging.error(f"Error in ECR repositories for region {region}: {str(e)}" )

        return ecr_assets_output


ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

AwsEcrAssets = ECR_ASSETS(account_id=accountid,regions=aws_regions)
ecr_assets=    [{
        "service"       : 'ECR',
        "friendly_name" : 'Elastic Container Registry',
        "subservices": {
            "repositories" : AwsEcrAssets.ECR_ASSETS()
        }        
    }]

print(json.dumps(ecr_assets,indent=2))