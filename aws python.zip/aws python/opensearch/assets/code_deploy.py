import boto3
import json
import logging
from datetime import datetime

class AwsCodeDeployAssets:    
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_code_deploy_inventory(self):
        next_token = None
        applications = []

        for region in self.regions:
            try:
                client = boto3.client('codedeploy', region_name=region)
                while True:
                    if next_token:
                        app_names_response = client.list_applications( 
                            nextToken = next_token
                        )
                    else:
                        app_names_response = client.list_applications()
                    for app_name in app_names_response["applications"]:
                        response = client.get_application(applicationName=app_name)
                        #app_data = response['application']
                        dg_names = client.list_deployment_groups(applicationName=app_name)
                        
                        for dg_name in dg_names['deploymentGroups']:
                            dg_response = client.get_deployment_group(
                                applicationName=app_name,
                                deploymentGroupName=dg_name
                            )              
                            last_attempted_deployment = dg_response['deploymentGroupInfo'].get('lastAttemptedDeployment', {})         
                            applications.append({
                                'name': app_name,
                                'computePlatform': response['application']['computePlatform'],
                                'createTime': datetime.strftime(response['application']['createTime'], '%Y-%m-%d'),
                                'DeploymentGroupName': dg_response['deploymentGroupInfo']['deploymentGroupName'],
                                'DeploymentType': dg_response['deploymentGroupInfo']['deploymentStyle']['deploymentType'],
                                'LastDeploymentStatus': last_attempted_deployment.get('status', 'N/A'),
                                'LastDeploymentTime': datetime.strftime(last_attempted_deployment['createTime'], '%Y-%m-%d') if 'createTime' in last_attempted_deployment else 'null'
                            })
                    next_token = app_names_response.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_code_deploy_inventory for region {region}: {str(e)}"
                )
                continue 
        return applications
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

codedeployassets =  AwsCodeDeployAssets(account_id=accountid, regions=aws_regions)

codedeployassets_assets = [
    {
        "service" : "CodeDeploy",
        "friendlyname" : "CodeDeploy",
        "subservice" : {
            "applications" : codedeployassets.get_code_deploy_inventory()
        }
    }
]

print(json.dumps(codedeployassets_assets, indent=2 ))
                
