import boto3
import json
import logging

class AwsConfigAssets:    
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_config_inventory(self):
        next_token = None
        config_rules = []
        for region in self.regions:
            try:
                client = boto3.client('config')
                while True:
                    if next_token:
                        response_names = client.describe_config_rules(
                            nextToken = next_token
                        )
                    else:
                        response_names = client.describe_config_rules()
                        for rule_names in response_names['ConfigRules']:
                            response = client.get_compliance_details_by_config_rule(ConfigRuleName=rule_names['ConfigRuleName'])
                            for rc_details in response['EvaluationResults']:
                                config_rules.append({
                                    'account'       : self.account_id,
                                    'region'        : region,
                                    'name'          : rc_details['EvaluationResultIdentifier']['EvaluationResultQualifier']['ConfigRuleName'],
                                    'resourceype'   : rc_details['EvaluationResultIdentifier']['EvaluationResultQualifier']['ResourceType'],
                                    'resourceid'    : rc_details['EvaluationResultIdentifier']['EvaluationResultQualifier']['ResourceId'],
                                    'compliancetype': rc_details['ComplianceType']
                                })
                    next_token = response.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_config_inventory for region {region}: {str(e)}"
                )
                continue 
            return config_rules
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')      
    
AwsConfigAssets =  AwsConfigAssets(account_id=accountid, regions=aws_regions)

AwsConfig_Assets = [
    {
        "service"      : "config",
        "friendlyname" : "AWS Config",
        "subservice"   : {
            "rules"   : AwsConfigAssets.get_config_inventory()
        }
    }
]                  
print(json.dumps(AwsConfig_Assets, indent=2))