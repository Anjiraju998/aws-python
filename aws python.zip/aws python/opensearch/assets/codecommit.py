import boto3
import json
import logging
from datetime import datetime

class AwsCodeCommitAssets:    
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_codecommit_inventory(self):
        next_token = None
        codecommit_repos = []
        for region in self.regions:
            try:
                client = boto3.client('codecommit')
                while True:
                    if next_token:
                        response = client.list_repositories(
                            nextToken = next_token
                        )
                    else:
                        response = client.list_repositories()    
                        for repo_response in response['repositories']:  
                            repo_names = client.get_repository(repositoryName=repo_response['repositoryName'])
                            codecommit_repos.append({
                                    'name'              : repo_names['repositoryMetadata']['repositoryName'],
                                    'defaultbranch'     : repo_names['repositoryMetadata']['defaultBranch'] if 'defaultBranch' in repo_names['repositoryMetadata'] else 'None',
                                    'creationdate'      : datetime.strftime(repo_names['repositoryMetadata']['creationDate'], '%Y-%m-%d'),
                                    'lastmodifieddate'  : datetime.strftime(repo_names['repositoryMetadata']['lastModifiedDate'], '%Y-%m-%d')
                                })
                    next_token = response.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_codecommit_inventory for region {region}: {str(e)}"
                )
                continue 
            return codecommit_repos
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')      
    
AwsCodeCommitAssets =  AwsCodeCommitAssets(account_id=accountid, regions=aws_regions)

AwsCodeCommit_Assets = [
    {
        "service"      : "CodeCommit",
        "friendlyname" : "CodeCommit",
        "subservice"   : {
            "repositories"   : AwsCodeCommitAssets.get_codecommit_inventory()
        }
    }
]      
    
print(json.dumps(AwsCodeCommit_Assets, indent=2))