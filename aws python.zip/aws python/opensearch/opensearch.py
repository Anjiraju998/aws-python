import boto3
from datetime import datetime, timezone 
import logging
import json

class AWSOpenSearchAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_opensearch_inventory(self):
        opensearch_data = []
        for region in self.regions:
            try:
                client = boto3.client('opensearch', region_name = region)
                opensearchl_list = client.list_domain_names()
                for opensearch in opensearchl_list["DomainNames"]:
                    opensearch_des = client.describe_domains(
                    DomainNames= [opensearch["DomainName"]]
                    )
                    for opensearchh in opensearch_des["DomainStatusList"]:
                        opensearchcluster = opensearchh["ClusterConfig"]
                        opensearch_data.append({
                        "account": self.account_id,
                        "region": region,
                        "domainname" : opensearchh["DomainName"],
                        "engineversion" : opensearchh["EngineVersion"],
                        "instancetype"  : opensearchh["ClusterConfig"]["InstanceType"],
                        "instancecount" : opensearchh["ClusterConfig"]["InstanceCount"],
                        "DedicatedMasterType" : opensearchcluster["DedicatedMasterType"] if "DedicatedMasterType" in opensearchcluster else "-",
                        "DedicatedMasterCount" : opensearchcluster["DedicatedMasterCount"] if "DedicatedMasterCount" in opensearchcluster else "-",
                        "ebsenabled" : opensearchh["EBSOptions"]["EBSEnabled"],
                        "volumetype" : opensearchh["EBSOptions"]["VolumeType"],
                        "volumesize" : opensearchh["EBSOptions"]["VolumeSize"],
                        "currentversion" : opensearchh["ServiceSoftwareOptions"]["CurrentVersion"]
                        })
            except Exception as e:
                logging.error(
                    f"Error in get_opensearch_inventory for region {region}: {str(e)}"
                )
                continue
        return opensearch_data

ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awsopensearchassets= AWSOpenSearchAssets(account_id=accountid,regions=aws_regions) 
opensearch_assets = [
    {
        "service" : "opensearch",
        "friendlyname": "opensearch ",
        "subservices" : {
            "domain" : awsopensearchassets.get_opensearch_inventory()
        }
    }
]

print(json.dumps(opensearch_assets, indent=2))  