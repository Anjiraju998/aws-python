import boto3
import json
from datetime import datetime
import logging

regions = ["us-east-1"]

for region in regions:
    response = client.get_dashboard(
    DashboardName='string'
)
    
