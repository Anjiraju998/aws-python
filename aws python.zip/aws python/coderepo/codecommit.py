import boto3
from datetime import datetime
import logging
import json

regions = ["us-east-1"]
repo_list = []
class AWSCodeCommitAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id
    def get_codecommit_inventory(self):
        next_token = None
        repo_data= [] 
        for region in self.regions:
            try:
                client = boto3.client('codecommit', region_name = region)
                while True:
                    if next_token:
                        repos_list = client.list_repositories(
                            nextToken = next_token
                        )
                    else:
                        repos_list = client.list_repositories()
                    for repo in repos_list["repositories"]:
                        commits = client.get_commit(
                            repositoryName=repo["repositoryName"],
                            commitId=repo["repositoryName"]
                        )
                        last_commit = commits["commit"]
                        repo_get = client.get_repository(
                        repositoryName=repo["repositoryName"]
                        )
                        repo = repo_get["repositoryMetadata"]
                        repo_data.append({
                            "repositoryname" : repo["repositoryName"],
                            "defaultbranch" : repo["defaultBranch"] if "defaultBranch" in repo else "null",
                            "creationdate" : datetime.strftime(repo["creationDate"], '%Y-%m-%d'),
                            "lastmodifieddate" : datetime.strftime(repo["lastModifiedDate"], '%Y-%m-%d'),
                            "commitid" : last_commit['commitId'],
                            "last_commit" : last_commit['message'],
                            "committername" : last_commit['committer']['name'],
                            "committernamedate" : last_commit['committer']['date']
                        })
                    next_token = repos_list.get('nextToken')
                    if not next_token:
                        break
            except Exception as e:
                logging.error(
                    f"Error in get_codecommit_inventory for region {region}: {str(e)}"
                )
                continue
        return repo_data
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awscodecommitassets=AWSCodeCommitAssets(account_id=accountid,regions=aws_regions)

acm_assets = [
    {
        "service" : "codecommit",
        "subservice" : {
            "codecommit": awscodecommitassets.get_codecommit_inventory()
        }
    }
]

print(json.dumps(acm_assets, indent=2))
            
        