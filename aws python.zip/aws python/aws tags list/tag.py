import boto3

def get_tagged_untagged_services():
    client = boto3.client('resourcegroupstaggingapi')

    tagged_services = set()
    untagged_services = set()

    try:
        paginator = client.get_paginator('get_resources')
        response_iterator = paginator.paginate()

        for response in response_iterator:
            for resource in response.get('ResourceTagMappingList', []):
                service = resource['ResourceARN'].split(":")[2]  # Extract service name from ARN
                tags = resource.get('Tags', [])

                if tags:
                    tagged_services.add(service)
                else:
                    untagged_services.add(service)

        return tagged_services, untagged_services
    except Exception as e:
        print(f"Error: {e}")
        return set(), set()

if __name__ == "__main__":
    tagged, untagged = get_tagged_untagged_services()

    print(f"\n✅ AWS Services with Tagged Resources ({len(tagged)}):")
    print(", ".join(sorted(tagged)))

    print(f"\n❌ AWS Services with Untagged Resources ({len(untagged)}):")
    print(", ".join(sorted(untagged)))
