import boto3
from datetime import datetime, timezone 
import logging
import json

class AWSIamAssets:          
    def __init__(self, account_id):
        self.account_id= account_id     
                               
#####################################    USERS     #######################################           
    def get_users_inventory(self):        
        try:
            client = boto3.client('iam') 
            IAM_user = []
            marker = None
            while True:
                if marker:
                    user_list = client.list_users(
                        Marker = marker
                    )
                else:
                    user_list = client.list_users()
                for user in user_list["Users"]:
                    markerkey = None
                    while True:
                        if marker:
                            key_lists = client.list_access_keys(
                                UserName = user["UserName"],
                                Marker = markerkey
                            )
                        else:    
                            key_lists = client.list_access_keys(
                                UserName = user["UserName"]
                            )
                            access_key_count = len(key_lists["AccessKeyMetadata"])
                        for key_list in key_lists["AccessKeyMetadata"]:
                            key_get = client.get_access_key_last_used(
                                AccessKeyId= key_list["AccessKeyId"]
                            )
                            keylast = key_get["AccessKeyLastUsed"]
                            AccessKeyLastUsed = keylast["LastUsedDate"] if "LastUsedDate" in keylast else None
                            if AccessKeyLastUsed is not None:
                                age = datetime.now(timezone.utc) - AccessKeyLastUsed 
                                accesskey_last_used = datetime.strftime(AccessKeyLastUsed, '%Y-%m-%d' )
                                Age = age.days
                            else:
                                Age = "Never Used"    
                                accesskey_last_used = "None"
                        user_des = client.get_user(
                            UserName = user["UserName"]
                        )
                        user_data = user_des["User"]  
                        codecommit_accesskeys = client.list_service_specific_credentials(
                        UserName= user["UserName"]
                        )
                        commit_date =[codecommit_key["CreateDate"] for codecommit_key in codecommit_accesskeys["ServiceSpecificCredentials"]]
                        letest_date = max(commit_date) if commit_date else None          
                        IAM_user.append({
                            "account": self.account_id,
                            "username" :  user["UserName"],
                            "creationdate" : datetime.strftime(user_data["CreateDate"], '%Y-%m-%d'),
                            "passwordlastused" : user_data["PasswordLastUsed"] if "PasswordLastUsed" in user_data else "None",
                            "accesskeycount" : access_key_count,
                            "accesskeylastuseddate" : accesskey_last_used,
                            "accesskeyage" : Age,
                            "codecommitkeycretiondate" : datetime.strftime(letest_date, '%Y-%m-%d') if letest_date else "None"
                        })
                        marker = key_lists.get('Marker')
                        if not marker:
                            break     
                marker = user_list.get('Marker')
                if not marker:
                    break 
        except Exception as e:
            logging.error(
                f"Error in get_users_inventory : {str(e)}"
            ) 
        return IAM_user

#########################################    GROUPS     ###########################################
    def get_group_inventory(self):        
        try:
            client = boto3.client('iam') 
            IAM_group = []
            marker = None
            while True:
                if marker:      
                    group_list = client.list_groups(
                        Marker = marker
                    )
                else:
                    group_list = client.list_groups()
                for group in group_list["Groups"]:
                    group_des = client.get_group(
                    GroupName = group["GroupName"]
                    )
                    group = group_des["Group"]
                    IAM_group.append({
                        "account": self.account_id,
                        "groupname" :  group["GroupName"],
                        "groupcreatedate" : datetime.strftime(group["CreateDate"], '%Y-%m-%d'),
                        "groupusername" : [user['UserName'] for user in group_des['Users']]
                    })
                marker = group_list.get('Marker')
                if not marker:
                    break                   
        except Exception as e:
            logging.error(
                f"Error in get_group_inventory : {str(e)}"
            ) 
        return IAM_group  

#######################################    ROLES     #########################################
    def get_role_inventory(self):
        try:
            client = boto3.client('iam') 
            IAM_roles = []
            marker = None
            while True:
                if marker:
                    roles_list = client.list_roles(
                        Marker = marker
                    )
                else:
                    roles_list = client.list_roles() 
                for role in roles_list["Roles"]:        
                    role_des = client.get_role(
                        RoleName= role["RoleName"]
                        )
                    role_d = role_des["Role"]
                    
                    if "Tags" in role_d:
                        role_tag = [f"{tag['Key']}: {tag['Value']}" for tag in role_d["Tags"]]
                    else:
                        role_tag = [] 
                    IAM_roles.append({
                        "account": self.account_id,
                        "rolename" : role["RoleName"],
                        "creationdate" : datetime.strftime(role_d["CreateDate"], '%Y-%m-%d'),
                        "lastused" : datetime.strftime(role_d["RoleLastUsed"]["LastUsedDate"], '%Y-%m-%d') if "LastUsedDate" in role_d["RoleLastUsed"] else "None",
                        "tags" : role_tag
                    })      
                marker = roles_list.get('Marker')
                if not marker:
                    break
        except Exception as e:
            logging.error(
                f"Error in get_role_inventory : {str(e)}"
            )
        return IAM_roles     
                    
#####################################    Customer Managed Policies     #######################################    
    def get_policy_inventory(self):        
        try:
            client = boto3.client('iam') 
            marker = None
            policy_data = []
            while True:
                if marker:
                    list_policies = client.list_policies(
                        Scope= "Local",
                        Marker = marker
                    ) 
                else:
                    list_policies = client.list_policies(
                        Scope= "Local"
                    )
                for policy in list_policies["Policies"]:
                    policy_des = client.get_policy(
                        PolicyArn = policy["Arn"]
                    )
                    policy = policy_des["Policy"]
                    policy_tag = [f"{tag['Key']}: {tag['Value']}" for tag in policy["Tags"]] if "Tags" in policy else []
                    policy_data.append({
                        "account": self.account_id,
                        "name" : policy["PolicyName"],
                        "creationdate" : datetime.strftime(policy["CreateDate"], '%Y-%m-%d'),
                        "lastmodifieddate" : datetime.strftime(policy["UpdateDate"], '%Y-%m-%d'),
                        "attachmentcount" : policy["AttachmentCount"],
                        "tags" : policy_tag    
                    })   
                marker = list_policies.get('Marker')
                if not marker:
                    break
        except Exception as e:
            logging.error(
                f"Error in get_policy_inventory : {str(e)}"
            )
        return policy_data      
    
########################################    Password Policy     ##########################################
    def get_pass_policy_inventory(self):
        client = boto3.client('iam') 
        pass_policy_list = []     
        try:
            pass_policy = client.get_account_password_policy()
            password_policy = pass_policy["PasswordPolicy"]          
            pass_policy_list.append({
                "account": self.account_id,
                "minimumpasswordlength" : password_policy["MinimumPasswordLength"],
                "requiresymbols" : password_policy["RequireSymbols"],
                "requirenumbers" : password_policy["RequireNumbers"],
                "requirelowercasecharacters" : password_policy["RequireLowercaseCharacters"],
                "allowUserstochangepassword" : password_policy["AllowUsersToChangePassword"],
                "expirepasswords" : password_policy["ExpirePasswords"],
                "maxpasswordage" : password_policy["MaxPasswordAge"] if "MaxPasswordAge" in password_policy else "None",
                "hardexpiry" : password_policy["HardExpiry"] if "HardExpiry" in password_policy else "None"                               
            })                              
        except Exception as e:
            logging.error(
                f"Error in get__pass_policy_inventory : {str(e)}"
            )
        return pass_policy_list

accountid=boto3.client('sts').get_caller_identity().get('Account')

awsiamassets=AWSIamAssets(account_id=accountid)
iam_assets = [
    {
        "service" : "iam",
        "friendlyname": "Identity and Access Management",
        "subservice" : {
            "users" : awsiamassets.get_users_inventory(),
            "groups" : awsiamassets.get_group_inventory(),
            "roles" : awsiamassets.get_role_inventory(),
            "policy" : awsiamassets.get_policy_inventory(),
            "passwordpolicy" : awsiamassets.get_pass_policy_inventory()
        }
    }
]

print(json.dumps(iam_assets, indent=2))
                    
             