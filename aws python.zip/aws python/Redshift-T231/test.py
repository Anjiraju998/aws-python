import boto3
from datetime import datetime, timezone 
import logging
import json

regions = ["ap-south-1"]
redishift_data = []
for region in regions:
    client = boto3.client('redshift', region_name = region)
    redishift_des = client.describe_clusters()
    for redishift in redishift_des["Clusters"]:
        snapshots = client.describe_cluster_snapshots()
    for snapshot in snapshots["Snapshots"]:
        redishift_data.append({
            "clusteridentifier" : redishift["ClusterIdentifier"],
            "nodetype" : redishift["NodeType"],
            "clustercreationtime" : redishift["ClusterCreateTime"],
            "availabilityzone" : redishift["AvailabilityZone"],
            "clusterversion" : redishift["ClusterVersion"],
            "numberofnodes" : redishift["NumberOfNodes"],
            "snapshotidentifier" : snapshot["SnapshotIdentifier"],
            "snapshottype" : snapshot["SnapshotType"],
            "snapshotcreatetime" : snapshot["SnapshotCreateTime"],
            "snapshotavailabilityZone" : snapshot["AvailabilityZone"],
            "snapshotstatus" : snapshot["Status"]
        })
    
    
    
    
    
    
    
    
    
    