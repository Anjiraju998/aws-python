import boto3
from datetime import datetime, timedelta
import time
import json

class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()

        return json.JSONEncoder.default(self, o)
class AWS_ACM:
    def __init__(self):
        self.regions = ["ap-south-1"]
        # ec2_client = boto3.client('ec2', region_name="us-east-1")
        # region_response = ec2_client.describe_regions()
        # for reg in region_response["Regions"]:
        #   regions.append(reg["RegionName"])

    def awsacm(self):
        next_token = None
        ACM_datas= [] 
        # acm_lists = client.list_certificates()
        for region in self.regions:
            try:
                client = boto3.client('acm', region_name= region) 
                while True:
                    if next_token:   
                        acm_lists = client.list_certificates(
                            nextToken = next_token)
                    else:
                        acm_lists = client.list_certificates()
        
                    for acm in acm_lists["CertificateSummaryList"]:
                        acm_arn = acm["CertificateArn"]         
                        try:
                            acm_des = client.describe_certificate(
                                CertificateArn= acm_arn
                            )
                            acm_data = acm_des["Certificate"]
                            domain_name = acm_data["DomainName"]
                            sub_alt_name = acm_data["SubjectAlternativeNames"]
                            # acm_subject = acm_data["Subject"]
                            acm_issuer = acm_data["Issuer"]
                            acm_createdat = acm_data["CreatedAt"]
                            acm_IssuedAt = acm_data["IssuedAt"]
                            acm_RenewalEligibility = acm_data["RenewalEligibility"]
                            acm_Status = acm_data["Status"]
                            acm_KeyAlgorithm = acm_data["KeyAlgorithm"]
                            acm_inuseby = acm_data["InUseBy"]
                            for DomainValidation in acm_data["DomainValidationOptions"]:
                                acm_validation = DomainValidation["ValidationStatus"]
                                acm_Val_Method = DomainValidation["ValidationMethod"]
                                acm_Val_Status = DomainValidation["ValidationStatus"]
                                
                                ACM_datas.append({
                                    "domain_name" : domain_name,
                                    "region": region,
                                    "acm_arn" : acm_arn,
                                    "sub_alt_name" : sub_alt_name,
                                    "acm_issuer" : acm_issuer,
                                    "acm_createdat" : acm_createdat,
                                    "acm_IssuedAt" : acm_IssuedAt,
                                    "acm_RenewalEligibility" : acm_RenewalEligibility,
                                    "acm_Status" : acm_Status,
                                    "acm_KeyAlgorithm" : acm_KeyAlgorithm,
                                    "acm_validation" : acm_validation,
                                    "acm_Val_Method" : acm_Val_Method,
                                    "acm_Val_Status" : acm_Val_Status,
                                    "acm_inuseby"  : acm_inuseby   
                    
                                    })
                        except Exception as e:
                            print("acm_des error")
                    next_token =  acm_lists.get('nextToken')  
                    if not next_token:
                        break
                
                        
            except Exception as e:
                print("acm_des error")
                            
        return json.dumps(ACM_datas, indent=2, cls=DateTimeEncoder)
ACM = AWS_ACM()
print(ACM.awsacm())
            

                # print(json.dumps(ACM_datas, indent=2, cls=DateTimeEncoder))
