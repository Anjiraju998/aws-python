import boto3
import logging

class AWSVPCAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id

    def get_vpc_inventory(self):
        vpc_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_vpcs(NextToken=next_token)
                    else:
                        response = client.describe_vpcs()
                    for vpc in response['Vpcs']:
                        if 'Tags' in vpc:
                            vpc_tags=[f"{tag['Key']}: {tag['Value']}" for tag in vpc['Tags']]
                        else:
                            vpc_tags=None
                        vpc_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "id": vpc['VpcId'],
                                "cidr": vpc['CidrBlock'],
                                "dhcp options id": vpc['DhcpOptionsId'],
                                "instance tenancy": vpc['InstanceTenancy'],
                                "is default": vpc['IsDefault'],
                                "tags": vpc_tags
                            }
                        )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_vpc_inventory for region {region}: {str(e)}"
                )
                continue
        return vpc_list

    def get_vpc_subnets_inventory(self):
        subnets_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_subnets(NextToken=next_token)
                    else:
                        response = client.describe_subnets()
                    for subnet in response['Subnets']:
                        if 'Tags' in subnet:
                            subnet_tags=[f"{tag['Key']}: {tag['Value']}" for tag in subnet['Tags']]
                        else:
                            subnet_tags=None
                        subnets_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "id": subnet['SubnetId'],
                                "cidr": subnet['CidrBlock'],
                                "vpc id": subnet['VpcId'],
                                "availability zone": subnet['AvailabilityZone'],
                                "available ips": subnet['AvailableIpAddressCount'],
                                "tags": subnet_tags
                            }
                        )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_vpc_subnets_inventory for region {region}: {str(e)}"
                )
                continue
        return subnets_list

    def get_vpc_nat_gateway_inventory(self):
        ngw_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_nat_gateways(NextToken=next_token)
                    else:
                        response = client.describe_nat_gateways()
                    for ngw in response['NatGateways']:
                        for address in ngw['NatGatewayAddresses']:
                            if address['IsPrimary']:
                                PublicIp = address.get('PublicIp')
                                PrivateIp = address.get('PrivateIp')                        
                        if 'Tags' in ngw:
                            ngw_tags=[f"{tag['Key']}: {tag['Value']}" for tag in ngw['Tags']]
                        else:
                            ngw_tags=None
                        ngw_list.append(
                                {
                                    "account": self.account_id,
                                    "region": region,
                                    "id": ngw['NatGatewayId'],
                                    "subnet": ngw['SubnetId'],
                                    "connectivity type": ngw['ConnectivityType'],
                                    "public ip": PublicIp,
                                    "privateIp": PrivateIp,
                                    "tags": ngw_tags
                                }
                            )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_vpc_nat_gateway_inventory for region {region}: {str(e)}"
                )
                continue
        return ngw_list