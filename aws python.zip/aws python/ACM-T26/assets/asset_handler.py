import boto3
from cloudfront import AWSCloudFrontAssets
from cloudwatch import AWSCloudwatchAssets
from ec2 import AWSEC2Assets
from lambda_functions import AWSLambdaAssets
from loadbalancer import AWSLBAssets
from s3 import AWSS3Assets
from vpc import AWSVPCAssets
import json

ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awscloudfrontassets=AWSCloudFrontAssets(account_id=accountid)
awscloudwatchassets=AWSCloudwatchAssets(account_id=accountid,regions=aws_regions)
awsec2assets=AWSEC2Assets(account_id=accountid,regions=aws_regions)
awslambdaassets=AWSLambdaAssets(account_id=accountid,regions=aws_regions)
awslbassets=AWSLBAssets(account_id=accountid,regions=aws_regions)
awss3assets=AWSS3Assets(account_id=accountid)
awsvpcassets=AWSVPCAssets(account_id=accountid,regions=aws_regions)

assets = [
    {
        "service": "CloudFront",
        "friendlyname": "CloudFront",
        "subservice": {
            "distributions": awscloudfrontassets.get_cloudfront_inventory()
        }
    },
    {
        "service": "Cloudwatch",
        "friendlyname": "Cloudwatch",
        "subservice": {
            "alarms": awscloudwatchassets.get_cloudwatch_alarms_inventory()
        }
    },
    {
        "service": "EC2",
        "friendlyname": "Elastic Cloud Compute",
        "subservice": {
            "instances": awsec2assets.get_ec2_instances_inventory(),
            "volumes": awsec2assets.get_ec2_volumes_inventory(),
            "images": awsec2assets.get_ec2_images_inventory(),
            "elastic ip": awsec2assets.get_ec2_elasticip_inventory(),
            "snapshots": awsec2assets.get_ec2_volume_snapshots_inventory(),
            "security groups": awsec2assets.get_ec2_security_groups_inventory(),
            "security group rules": awsec2assets.get_ec2_security_group_rules_inventory()
        }
    },
    {
        "service": "Lambda",
        "friendlyname": "Lambda",
        "subservice": {
            "functions": awslambdaassets.get_lambda_functions_inventory()
        }
    },
    {
        "service": "ELB",
        "friendlyname": "Elastic Load Balancer",
        "subservice": {
            "classic load balancers": awslbassets.get_classic_load_balancer_inventory(),
            "application load balancers": awslbassets.get_load_balancer_inventory(type='application'),
            "network load balancers": awslbassets.get_load_balancer_inventory(type='network'),
            "gateway load balancers": awslbassets.get_load_balancer_inventory(type='gateway')
        }
    },
    {
        "service": "S3",
        "friendlyname": "Simple Storage Service",
        "subservice": {
            "s3 buckets": awss3assets.get_s3_buckets_inventory()
        }
    },
    {
        "service": "VPC",
        "friendlyname": "Virtual Private Cloud",
        "subservice": {
            "vpc": awsvpcassets.get_vpc_inventory(),
            "subnets": awsvpcassets.get_vpc_subnets_inventory(),
            "nat gateways": awsvpcassets.get_vpc_nat_gateway_inventory()
        }
    }
]

print(json.dumps(assets))
