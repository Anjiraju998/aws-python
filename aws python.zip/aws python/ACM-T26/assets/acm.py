import boto3
import logging
import json
from datetime import datetime

class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()
        return json.JSONEncoder.default(self, o)

class AWSAcmAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id

    def get_acm_inventory(self):
        next_token = None
        ACM_datas= [] 
        for region in self.regions:
            try:
                client = boto3.client('acm', region_name= region) 
                while True:
                    if next_token:   
                        acm_lists = client.list_certificates(
                            nextToken = next_token)
                    else:
                        acm_lists = client.list_certificates()
                    for acm in acm_lists["CertificateSummaryList"]:        
                        acm_des = client.describe_certificate(
                            CertificateArn= acm["CertificateArn"]
                        )
                        acm_data = acm_des["Certificate"]       
                        ACM_datas.append({
                            "account": self.account_id,
                            "region": region,
                            "domain_name" : acm_data["DomainName"],
                            "sub_alt_name" : [subdomain for subdomain in acm_data["SubjectAlternativeNames"] if subdomain != acm_data["DomainName"]],
                            "acm_Status" : acm_data["Status"],
                            "acm_inuseby"  : acm_data["InUseBy"],
                            "acm_IssuedAt" : datetime.strftime(acm_data["IssuedAt"], '%Y-%m-%d'),
                            "expirydate" : datetime.strftime(acm_data["NotAfter"], '%Y-%m-%d')                                   
                        })
                    
                    next_token =  acm_lists.get('nextToken')  
                    if not next_token:
                        break                        
            except Exception as e:
                logging.error(
                    f"Error in get_acm_inventory for region {region}: {str(e)}"
                )
                continue                   
        return ACM_datas
    
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awsacmassets=AWSAcmAssets(account_id=accountid,regions=aws_regions)

acm_assets = [
    {
        "service" : "acm",
        "subservice" : {
            "projects" : awsacmassets.get_acm_inventory()
        }
    }
]

print(json.dumps(acm_assets, indent=2, cls=DateTimeEncoder))

