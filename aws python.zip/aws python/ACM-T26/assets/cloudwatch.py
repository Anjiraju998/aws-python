import boto3
import json
import logging
from datetime import datetime

class AWSCloudwatchAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id

    def get_cloudwatch_alarms_inventory(self):
        alarm_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('cloudwatch', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_alarms(NextToken=next_token)
                    else:
                        response = client.describe_alarms()
                    for metricalarm in response['MetricAlarms']:                            
                        if 'Tags' in metricalarm:
                            metricalarm_tags=[f"{tag['Key']}: {tag['Value']}" for tag in metricalarm['Tags']]
                        else:
                            metricalarm_tags=None
                        alarm_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "alarm name": metricalarm['AlarmName'],
                                "tags": metricalarm_tags
                            }
                        )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_cloudwatch_alarms_inventory for region {region}: {str(e)}"
                )
                continue

        return alarm_list