import boto3
import logging

class AWSLBAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id

    def get_classic_load_balancer_inventory(self):
        classic_load_balancer_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('elb', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_load_balancers(NextToken=next_token)
                    else:
                        response = client.describe_load_balancers()
                    for clb in response['LoadBalancerDescriptions']:
                        if 'Tags' in clb:
                            clb_tags=[f"{tag['Key']}: {tag['Value']}" for tag in clb['Tags']]
                        else:
                            clb_tags=None
                        classic_load_balancer_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "name": clb['LoadBalancerName'],
                                "dns": clb['DNSName'],
                                "scheme": clb['Scheme'],
                                "vpcid": clb['VPCId'],
                                "tags": clb_tags
                            }
                        )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_classic_load_balancer_inventory for region {region}: {str(e)}"
                )
                continue
        return classic_load_balancer_list

    def get_load_balancer_inventory(self, type):
        load_balancer_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('elbv2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_load_balancers(NextToken=next_token)
                    else:
                        response = client.describe_load_balancers()
                    for lb in response['LoadBalancers']:
                        if lb['Type'] == type:
                            if 'Tags' in lb:
                                lb_tags=[f"{tag['Key']}: {tag['Value']}" for tag in lb['Tags']]
                            else:
                                lb_tags=None
                            load_balancer_list.append(
                                {
                                    "account": self.account_id,
                                    "region": region,
                                    "name": lb['LoadBalancerName'],
                                    "dns": lb['DNSName'],
                                    "scheme": lb['Scheme'],
                                    "vpc id": lb['VpcId'],
                                    "tags": lb_tags
                                }
                            )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_load_balancer_inventory for region {region}: {str(e)}"
                )
                continue
        return load_balancer_list