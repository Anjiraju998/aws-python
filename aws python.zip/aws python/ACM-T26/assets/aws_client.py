import logging
import boto3

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class AwsClient:
    def __init__(self, role_arn, role_session_name, external_id):
        self.role_arn = role_arn
        self.role_session_name = role_session_name
        self.external_id = external_id

    def _get_session(self, region):
        # Assume the role associated with the credentials
        sts_url = "https://sts." + region + ".amazonaws.com"
        sts_client = boto3.client("sts", region_name=region, endpoint_url=sts_url)
        role_session_name = self.role_session_name
        assumed_role = sts_client.assume_role(
            RoleArn=self.role_arn,
            RoleSessionName=role_session_name,
            ExternalId=self.external_id,
        )
        credentials = assumed_role["Credentials"]
        access_key = credentials["AccessKeyId"]
        secret_key = credentials["SecretAccessKey"]
        session_token = credentials["SessionToken"]
        return boto3.Session(
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            aws_session_token=session_token,
        )

    def get_client(self, service_name, region="us-east-1"):
        try:
            session = self._get_session(region)
            return session.client(service_name=service_name, region_name=region)
        except Exception as e:
            logger.error(f"Error in get_client: {str(e)}")
            raise e

    def region_validation(self, region):
        try:
            sts_url = "https://sts." + region + ".amazonaws.com"
            sts_client = boto3.client("sts", region_name=region, endpoint_url=sts_url)
            role_session_name = self.role_session_name
            sts_client.assume_role(
                RoleArn=self.role_arn,
                RoleSessionName=role_session_name,
                ExternalId=self.external_id,
            )

            return True
        except Exception as e:
            logger.error(
                f"Error in assume role for the following region: {region} and {e}"
            )
            return False
