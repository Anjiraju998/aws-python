import boto3
import logging
from datetime import datetime

class AWSEC2Assets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id=account_id

    def get_ec2_instances_inventory(self):
        instance_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_instances(NextToken=next_token)
                    else:
                        response = client.describe_instances()
                    for reservation in response['Reservations']:
                        for instance in reservation['Instances']:
                            if 'Tags' in instance:
                                instance_tags=[f"{tag['Key']}: {tag['Value']}" for tag in instance['Tags']]
                            else:
                                instance_tags=None
                            instance_list.append(
                                {
                                    "account": self.account_id,
                                    "region": region,
                                    "instance id": instance['InstanceId'],
                                    "instance type": instance['InstanceType'],
                                    "private ip": instance['PrivateIpAddress'],
                                    "public ip": instance.get('PublicIpAddress'),
                                    "status": instance['State']['Name'],
                                    "platform": instance['PlatformDetails'],
                                    "tags": instance_tags
                                }
                            )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_ec2_instances_inventory for region {region}: {str(e)}"
                )
                continue
        return instance_list

    def get_ec2_volumes_inventory(self):
        volume_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_volumes(NextToken=next_token)
                    else:
                        response = client.describe_volumes()
                    for volume in response['Volumes']:
                        attachments = volume.get('Attachments', [])
                        if 'Tags' in volume:
                            volume_tags=[f"{tag['Key']}: {tag['Value']}" for tag in volume['Tags']]
                        else:
                            volume_tags=None
                        volume_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "id": volume['VolumeId'],
                                "type": volume['VolumeType'],
                                "size(in GB)": volume['Size'],
                                "state": volume['State'],
                                "encryption": 'Encrypted' if volume['Encrypted'] else 'Not Encrypted',
                                "az": volume['AvailabilityZone'],
                                "instance id": attachments[0]['InstanceId'] if attachments != [] else "-",
                                "creation date": datetime.strftime(volume['CreateTime'], '%Y-%m-%d'),
                                "tags": volume_tags
                            }
                        )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_ec2_volumes_inventory for region {region}: {str(e)}"
                )
                continue
        return volume_list

    def get_ec2_images_inventory(self):
        images_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_images(Owners=['self'],NextToken=next_token)
                    else:
                        response = client.describe_images(Owners=['self'])
                    for image in response['Images']:
                            if 'Tags' in image:
                                image_tags=[f"{tag['Key']}: {tag['Value']}" for tag in image['Tags']]
                            else:
                                image_tags=None
                            images_list.append(
                                {
                                    "account": self.account_id,
                                    "region": region,
                                    "name": image['Name'],
                                    "id": image['ImageId'],
                                    "platform": image['PlatformDetails'],
                                    "root device type": image['RootDeviceType'],
                                    "visibility": 'Public' if image['Public'] else 'Private',
                                    "creation date": image['CreationDate'].split('T')[0],
                                    "tags": image_tags
                                }
                            )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_ec2_images_inventory for region {region}: {str(e)}"
                )
                continue
        return images_list

    def get_ec2_elasticip_inventory(self):
        eip_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_addresses(NextToken=next_token)
                    else:
                        response = client.describe_addresses()
                    for addresses in response['Addresses']:
                        if 'Tags' in addresses:
                            eip_tags=[f"{tag['Key']}: {tag['Value']}" for tag in addresses['Tags']]
                        else:
                            eip_tags=None
                        eip_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "public ip": addresses['PublicIp'],
                                "private ip": addresses.get('PrivateIpAddress'),
                                "domain": addresses['Domain'],
                                "tags": eip_tags
                            }
                        )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_ec2_elasticip_inventory for region {region}: {str(e)}"
                )
                continue
        return eip_list

    def get_ec2_volume_snapshots_inventory(self):
        snapshot_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_snapshots(OwnerIds=['self'],NextToken=next_token)
                    else:
                        response = client.describe_snapshots(OwnerIds=['self'])
                    for snapshot in response['Snapshots']:
                        if 'Tags' in snapshot:
                            snapshot_tags=[f"{tag['Key']}: {tag['Value']}" for tag in snapshot['Tags']]
                        else:
                            snapshot_tags=None
                        snapshot_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "id": snapshot['SnapshotId'],
                                "volumeid": snapshot['VolumeId'],
                                "size(in GB)": snapshot['VolumeSize'],
                                "encryption": 'Encrypted' if snapshot['Encrypted'] else 'Not Encrypted',#snapshot['Encrypted'],
                                "creation date": datetime.strftime(snapshot['StartTime'], '%Y-%m-%d'),
                                "tags": snapshot_tags
                            }
                        )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_ec2_volume_snapshots_inventory for region {region}: {str(e)}"
                )
                continue
        return snapshot_list

    def get_ec2_security_groups_inventory(self):
        security_group_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_security_groups(NextToken=next_token)
                    else:
                        response = client.describe_security_groups()
                    for securitygroup in response['SecurityGroups']:
                        if 'Tags' in securitygroup:
                            securitygroup_tags=[f"{tag['Key']}: {tag['Value']}" for tag in securitygroup['Tags']]
                        else:
                            securitygroup_tags=None
                        security_group_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "group name": securitygroup['GroupName'],
                                "group id": securitygroup['GroupId'],
                                "vpcid": securitygroup['VpcId'],
                                "tags": securitygroup_tags
                            }
                        )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_ec2_security_groups_inventory for region {region}: {str(e)}"
                )
                continue
        return security_group_list

    def get_ec2_security_group_rules_inventory(self):
        security_group_rules_list = []
        next_token = None
        for region in self.regions:
            try:
                client = boto3.client('ec2', region_name=region)
                while True:
                    if next_token:
                        response = client.describe_security_group_rules(NextToken=next_token)
                    else:
                        response = client.describe_security_group_rules()
                    for securitygrouprule in response['SecurityGroupRules']:
                        referenced_group_info = securitygrouprule.get('ReferencedGroupInfo', {})
                        if 'Tags' in securitygrouprule:
                            securitygrouprule_tags=[f"{tag['Key']}: {tag['Value']}" for tag in securitygrouprule['Tags']]
                        else:
                            securitygrouprule_tags=None
                        security_group_rules_list.append(
                            {
                                "account": self.account_id,
                                "region": region,
                                "rule id": securitygrouprule['SecurityGroupRuleId'],
                                "group id": securitygrouprule['GroupId'],
                                "type": 'Outbound' if securitygrouprule['IsEgress'] else 'Inbound',
                                "ports": str(securitygrouprule['FromPort']) if securitygrouprule['FromPort'] == securitygrouprule['ToPort'] else f"{securitygrouprule['FromPort']}-{securitygrouprule['ToPort']}",
                                "protocol": securitygrouprule['IpProtocol'],
                                "endpoint": next((value for value in (securitygrouprule.get('CidrIpv4'), securitygrouprule.get('CidrIpv6'), securitygrouprule.get('PrefixListId'), referenced_group_info.get('GroupId')) if value is not None), None),
                                "tags": securitygrouprule_tags
                            }
                        )
                    next_token = response.get('NextToken')
                    if not next_token:
                        break
                        
            except Exception as e:
                logging.error(
                    f"Error in get_ec2_security_group_rules_inventory for region {region}: {str(e)}"
                )
                continue
        return security_group_rules_list
