import boto3
from datetime import datetime
import logging
import json

class AWSKmsAssets:
    def __init__(self, account_id, regions):
        self.regions = regions
        self.account_id= account_id

    def get_kms_inventory(self):
        next_token = None
        KMS_data= []
        for region in self.regions:
            try:
                client = boto3.client('kms', region_name=region)
                while True:
                    if next_token:
                        keys_list = client.list_keys(
                            nextToken = next_token)
                    else:
                        keys_list = client.list_keys()                            
                    for key_list in keys_list["Keys"]:
                        key_des= client.describe_key(
                            KeyId = key_list["KeyId"]
                        )                             
                        key_data = key_des['KeyMetadata']                
                        KMS_data.append({
                            "account": self.account_id,
                            "region": region,
                            "keyid" : key_list["KeyId"],
                            "creationdate" : datetime.strftime(key_data['CreationDate'], '%Y-%m-%d'),
                            "validity" : key_data["ValidTo"] if "ValidTo" in key_data else "None",
                            "keyusage" : key_data["KeyUsage"],
                            "keytype" : key_data["KeyManager"],
                            "multiregion" : key_data["MultiRegion"]       
                        })
                    next_token = keys_list.get('nextToken')
                    if not next_token:
                        break            
            except Exception as e:
                logging.error(
                    f"Error in get_kms_inventory for region {region}: {str(e)}"
                )
                continue 
        return KMS_data
ec2_client = boto3.client('ec2', region_name="us-east-1")
aws_regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
accountid=boto3.client('sts').get_caller_identity().get('Account')

awskmsassets=AWSKmsAssets(account_id=accountid,regions=aws_regions)

kms_assets = [
    {
        "service" : "MSK",
        "friendlyname": "Managed Streaming for Apache Kafka",
        "subservice" : {
            "msk cluster" : awskmsassets.get_kms_inventory()
        }
    }
]

print(json.dumps(kms_assets, indent=2))

